<?php
namespace Core;

use \App\Models\Account;
use \App\Models\User;
use \App\Auth;

abstract class Controller
{

	protected $route_params = [];

	protected $instagram;

	protected $account;
	
	protected $user;
	
	protected $data;
	
	protected $user_details;
	
	protected $token;
	
	protected $query_hash;
	
	protected $auth;
	
	public $insta_login;
	
	

	public function __construct($route_params) {
		$this->route_params = $route_params;
		$this->account = new Account();
		$this->user = new User();
		$this->auth = new Auth();
		\InstagramAPI\Instagram::$allowDangerousWebUsageAtMyOwnRisk = true;
		
	}

	public function __call($name, $args) {

		$method = $name."Action";

		if(method_exists($this, $method)) {
			if($this->before() !== false) {
				call_user_func_array([$this, $method], $args);
				$this->after();
			}
		} else {
			// echo "Method $method not found in the controller".get_class($this);
			throw new \Exception("Method $method not found in controller ".get_class($this));
		}
	}
	
	protected function post_insta($url, $fields, $cookie_file, $proxy, $header = null) {
		$ch = curl_init();

		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_VERBOSE, true);
		curl_setopt($ch, CURLOPT_HEADER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		if(!empty($header)) {
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header); 
		}
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
		curl_setopt($ch, CURLOPT_CAINFO, realpath("user/DigiCertHighAssuranceEVRootCA.crt"));
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
		if($proxy != "") {
			curl_setopt($ch, CURLOPT_PROXY, trim($proxy));
		}
		curl_setopt($ch, CURLOPT_COOKIEJAR, realpath($cookie_file));
		curl_setopt($ch, CURLOPT_COOKIEFILE, realpath($cookie_file));
		$result = curl_exec($ch);

		$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
		$header = substr($result, 0, $header_size);
		$body = substr($result, $header_size);


		curl_close($ch);

		return array('header'	=>	$header,'body'	=>	$body);

		}
		
	protected function visit($cookie_file, $proxy, $header = null) {

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, 'https://www.instagram.com/accounts/login/');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		if(!empty($header)) {
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header); 
		}
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
		curl_setopt($ch, CURLOPT_CAINFO, realpath("user/DigiCertHighAssuranceEVRootCA.crt"));
		if($proxy != "") {
			curl_setopt($ch, CURLOPT_PROXY, trim($proxy));
		}
		curl_setopt($ch, CURLOPT_COOKIEJAR, realpath($cookie_file));

		$result = curl_exec($ch);
		curl_close($ch);

		if($result) {
		return $result;
		}

	}
	
	protected function link_visit($url, $cookie_file, $proxy, $header = null) {

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		if(!empty($header)) {
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header); 
		}
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
		curl_setopt($ch, CURLOPT_CAINFO, realpath("user/DigiCertHighAssuranceEVRootCA.crt"));
		if($proxy != "") {
			curl_setopt($ch, CURLOPT_PROXY, trim($proxy));
		}
		curl_setopt($ch, CURLOPT_COOKIEJAR, realpath($cookie_file));

		$result = curl_exec($ch);
		curl_close($ch);

		if($result) {
		return $result;
		}

	}
	
	protected function silent_visit($url, $cookie_file, $proxy, $referer = "") {
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		if($referer != "") {
		curl_setopt($ch, CURLOPT_REFERER, $referer);
		}
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
		curl_setopt($ch, CURLOPT_CAINFO, realpath("user/DigiCertHighAssuranceEVRootCA.crt"));
		if($proxy != "") {
			curl_setopt($ch, CURLOPT_PROXY, trim($proxy));
		}
		curl_setopt($ch, CURLOPT_COOKIEFILE, realpath($cookie_file));
		$result = curl_exec($ch);
		curl_close($ch);
		
		if($result) { 
		return $result;
		}
		
	}
	
	protected function recursive_array_search($needle,$haystack) {
		
    foreach($haystack as $key=>$value) {
        $current_key=$key;
        
        if($needle===$value OR (is_array($value) && recursive_array_search($needle,$value) !== false)) {
            return $current_key;
        }
        
    }
    
	 return false;
	}
	
	protected function check_proxy($proxy) {
		
		$ch = curl_init();
	
		curl_setopt($ch, CURLOPT_URL, 'https://www.google.com');
		curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_VERBOSE, true);
		curl_setopt($ch, CURLOPT_HEADER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10); 
		curl_setopt($ch, CURLOPT_TIMEOUT, 10); //timeout in seconds
		curl_setopt($ch, CURLOPT_PROXY, trim($proxy));

		$result = curl_exec($ch);
		
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

		curl_close($ch);
		
		if($httpcode) {
			return true;
		} else {
			return false;
		}
		
	}

	protected function redirect($url) {
		header('Location: http://'.$_SERVER['HTTP_HOST'].$url,	true,	303);
	}

	protected function before() {
	}

	protected function after() {
	}

}

?>
