{% extends "userbase.php" %}
{% block content %}
<div id="signup" class="simpleform">
    <h1 class="title">Sign up to <br> managing Instagram!</h1>
    <form action="{{ site_path }}/growth/create" method="POST">
      <div class="form-group">
        <input type="text" name="f_name" class="form-control" placeholder="Firstname" />
      </div>
      <div class="form-group">
        <input type="text" name="l_name" class="form-control" placeholder="Lastname" />
      </div>
      <div class="form-group">
        <input type="email" name="acc_email" class="form-control" placeholder="Email Address" />
      </div>
      <div class="form-group">
        <input type="password" name="acc_pass" class="form-control" placeholder="Password" />
      </div>
      <div class="form-group">
        <input type="password" name="acc_pass_confirm" class="form-control" placeholder="Confirm Password" />
      </div>
      <div class="mt-5 login-buttons">
            <button class="custom-button signin-btn fluid-btn" type="submit" name="submit-login"><span class="text-button">Get Started</span></button><br>
      </div>
    </form>
    <div class="sub">
        <div>By creating an acount you agree to our terms of service.</div>
        <a href="{{ site_path }}/growth/login">Already have an account?</a>
    </div>
</div>
{% endblock %}
