Neptune - Nextpost Instagram Landing Page


Installation:
1. Rename the /inc/themes/default/ directory to anything else in your server. Or
take a backup and remove this directory from the the server (your site of Nextpost).

2. Upload the "default" directory from this archive to the /inc/themes/ directory 
in your server (your site of Nextpost). 