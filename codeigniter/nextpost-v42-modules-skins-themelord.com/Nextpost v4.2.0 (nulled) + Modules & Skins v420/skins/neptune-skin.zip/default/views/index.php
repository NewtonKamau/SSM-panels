<?php if (!defined('APP_VERSION')) die("Yo, what's up?"); ?>
<!doctype html>
<html lang="<?= ACTIVE_LANG ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>
        <meta name="theme-color" content="#fff">

        <meta name="description" content="<?= site_settings("site_description") ?>">
        <meta name="keywords" content="<?= site_settings("site_keywords") ?>">

        <link rel="icon" href="<?= site_settings("logomark") ? site_settings("logomark") : active_theme_url() . "/assets/images/favicon.ico"?>" type="image/x-icon">
        <link rel="shortcut icon" href="<?= site_settings("logomark") ? site_settings("logomark") : active_theme_url() . "/assets/images/favicon.ico"?>" type="image/x-icon">
        
        <link rel="stylesheet" type="text/css" href="<?= active_theme_url() . "/assets/styles/vendor.css?v=neptun010002" . VERSION ?>">
        <link rel="stylesheet" type="text/css" href="<?= active_theme_url() . "/assets/styles/main.css?v=neptun010002" . VERSION ?>">

       <title><?= site_settings("site_name") ?></title>
    </head>

    <body>
        <header>
            <div class="wrapper">
                <nav class="flex flex-start flex-middle">
                    <div class="brand-logo flex-align-left">
                        <a href="<?= APPURL ?>">
                            <img src="<?= site_settings("logotype") ? site_settings("logotype") : active_theme_url() . "/assets/images/logo.svg"?>"
                                 alt="<?= site_settings("site_name") ?>">
                            </a>
                    </div>

                    <div class="menu">
                        <ul>
                            <li>
                                <a href="#" data-scroll='about'><?=__("About")?></a>
                            </li>
                            <li>
                                <a href="#" data-scroll='features'><?=__("Features")?></a>
                            </li>
                            <li>
                                <a href="#" data-scroll='pricing'><?=__("Pricing")?></a>
                            </li>

                            <?php if ($AuthUser): ?>
                                <li>
                                    <a href="<?= APPURL . "/profile/" ?>">
                                        <?=__("Hi, %s", htmlchars($AuthUser->get("firstname")))?>
                                    </a>
                                </li>
                            <?php else: ?>
                                <li><a href="<?=APPURL . "/login"?>"><?=__("Login")?></a></li>
                                <li><a href="<?=APPURL . "/signup"?>" class="border-lined"><?=__("Sign up")?></a></li>
                            <?php endif?>
                        </ul>
                    </div>

                    <?php if (!$AuthUser): ?>
                        <?php $langs = Config::get("applangs"); ?>
                        <div class="language dropdown dropdown-click">
                            <?php foreach ($langs as $l): ?>
                                <?php if ($l["code"] == ACTIVE_LANG): ?>
                                    <span class="active">
                                        <?= $l["name"] ?>
                                        <i class="icon icon-arrow-down"></i>
                                    </span>
                                    <?php break; ?>
                                <?php endif ?>
                            <?php endforeach ?>

                            <div class="dropdown-list">
                                <ul class="language-list">
                                    <?php foreach ($langs as $l): ?>
                                        <li>
                                            <a href="<?= APPURL . "/" . $l["code"] ?>"><?= $l["name"] ?></a>
                                        </li>
                                    <?php endforeach?>
                                </ul>
                            </div>
                        </div>

                        <div class="menu-toggle">
                            <div class="trigger"></div>
                        </div>
                    <?php endif;?>
                </nav>
            </div>
        </header>

        <section id="home-top">
            <div class="wrapper">
                <div id="info">
                    <div class="info-holder" data-animation-role='main-container' data-positon='left'>
                        <div class="content-wrapper">
                            <div class="content flex flex-end flex-top flex-col" data-animation-role='content'>
                                <div class="icon animated-start">
                                    <i class="icon-clock icon"></i>
                                </div>

                                <div class="desc animated-start">
                                    <p><?= __("Save time managing your Instagram accounts") ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="info-holder" data-animation-role='main-container' data-positon='center'>
                        <div class="content-wrapper">
                            <div class="content flex flex-end flex-top flex-col" data-animation-role='content'>
                                <div class="icon animated-start">
                                    <i class="icon-paper-plane icon"></i>
                                </div>

                                <div class="desc animated-start">
                                    <p><?= __("A Smarter way to auto post on instagram") ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="info-holder" data-animation-role='main-container' data-positon='right'>
                        <div class="content-wrapper">
                            <div class="content flex flex-end flex-top flex-col" data-animation-role='content'>
                                <div class="icon animated-start">
                                    <i class="icon-calendar icon"></i>
                                </div>

                                <div class="desc animated-start">
                                    <p><?= __("Schedule your posts to any future date") ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="end-desc flex flex-middle flex-center flex-col">
                <div class="desc flex-align-bottom">
                    <div class="details">
                        <h1><?= __("A Smarter way to <br> Auto Post on Instagram") ?></h1>
                    </div>

                    <div class="link">
                        <a href="<?= APPURL . "/signup" ?>" class="button-style purple"><?=__("Get started")?></a>
                    </div>
                </div>
            </div>

            <div class="lines">
                <span class="line" data-toward='horizontal'></span>
                <span class='line' data-toward='vertical'></span>
            </div>
        </section>
        
        <section id='manage'  data-scroll='about'>
            <div class="wrapper">
                <div class="manage-holder flex flex-between flex-wrap">
                    <div class="feature-list inline">
                        <div class="list-heading">
                            <div class="heading-title">
                                <h1><?= __("Manage your accounts") ?></h1>
                            </div>
                            <div class="desc-text">
                                <p><?= __("The following features to help you save time") ?></p>
                            </div>
                        </div>

                        <div class="list-item ">
                            <div class="item-holder flex flex-middle">
                                <div class="left inline"> <i class="icon-people"></i> </div>
                                <div class="right inline">
                                    <div class="heading-title">
                                        <h3><?= __("Multi Instagram Accounts") ?></h3>
                                    </div>
                                    <div class="desc-text"><?= __("Post the same content to all accounts") ?></div>
                                </div>
                            </div>
                        </div>

                        <div class="list-item">
                            <div class="item-holder flex flex-middle">
                                <div class="left inline"> <i class="icon-film"></i> </div>
                                <div class="right inline">
                                    <div class="heading-title">
                                        <h3><?= __("Photo, Story, Video & Album") ?></h3>
                                    </div>
                                    <div class="desc-text"><?= __("Automatically post all content") ?></div>
                                </div>
                            </div>
                        </div>

                        <div class="list-item">
                            <div class="item-holder flex flex-middle">
                                <div class="left inline"> <i class="icon-calendar"></i> </div>
                                <div class="right inline">
                                    <div class="heading-title">
                                        <h3><?= __("Schedule Posts")?></h3>
                                    </div>
                                    <div class="desc-text"><?= __("You don't need to worry about managment") ?></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-holder flex-grow flex flex-center">
                        <div class="contact-form">
                            <form action="<?= APPURL."/signup" ?>" method="POST" autocomplete="off">
                                <input type="hidden" name="action" value="signup">
                                
                                <div class="form <?= $AuthUser ? "complete" : "" ?>">
                                    <div class="form-heading">
                                        <div class="desc-text">
                                            <p><?= __("Future starts today") ?></p>
                                        </div>
                                    </div>

                                    <div class="form-body">
                                        <div class="form-element">
                                            <div class="input-wrapper">
                                                <input type="text" name="firstname" placeholder="<?= __('Firstname') ?>">
                                                <i class="icon icon-user"></i>
                                            </div>

                                            <div class="input-wrapper">
                                                <input type="text" name="lastname" placeholder="<?= __('Lastname') ?>">
                                                <i class="icon icon-user"></i>
                                            </div>
                                            
                                            <div class="input-wrapper">
                                                <input type="email" name="email" placeholder="<?= __("Email") ?>">
                                                <i class="icon icon-envelope-open"></i>
                                            </div>
                                            
                                            <div class="input-wrapper">
                                                <input type="password" name="password" placeholder="<?= __("Password") ?>">
                                                <i class="icon icon-key"></i>
                                            </div>
                                            
                                            <div class="input-wrapper">
                                                <input type="password" name="password-confirm" placeholder="<?= __("Confirm password") ?>">
                                                <i class="icon icon-key"></i>
                                            </div>
                                            
                                            <div class="input-wrapper dropdown dropdown-click timezone" data-role='list-holder'>
                                                <?php 
                                                    $tz = $IpInfo->timezone;
                                                    $timezones = getTimezones();

                                                    $active_timezone = "";
                                                    if (isset($timezones[$tz])) {
                                                        $active_timezone = $timezones[$tz];   
                                                    }

                                                    if (\Input::post("timezone")) {
                                                        $active_timezone = \Input::post("timezone");
                                                    }
                                                ?>
                                                <input data-role="value" type="text" class="dropdown-append-value timezone-value <?= $active_timezone ? "has-value" : "" ?>" placeholder="<?= __("Select your timezone") ?>" name="timezone" value="<?= $active_timezone ?>">
                                                <i class="icon icon-clock"></i>
                                                <div class="dropdown-list js-timezone-dropdown timezone-list">
                                                    <ul data-role="list">
                                                        <?php foreach ($timezones as $k => $v): ?>
                                                            <li>
                                                                <a href="#" data-list-item data-value='<?= $k ?>'><?= $v ?></a>
                                                            </li>
                                                        <?php endforeach; ?>
                                                    </ul>
                                                </div>
                                            </div>
                                            
                                            <div class="input-wrapper">
                                                <button type="submit" class="button-style purple"><?=__("Get started")?></button>
                                            </div>
                                        </div>

                                        <div class="success-status">
                                            <div class="status">
                                                <i class="icon-check icon"></i>
                                            </div>
                                            
                                            <div class="heading-title">
                                                <h1><?=__("Welcome!")?></h1>
                                            </div>
                                            
                                            <div class="desc-text">
                                                <p>
                                                    <?=__("You've been <br> logged in successfully.")?>
                                                </p>
                                            </div>
                                            
                                            <a href="<?= APPURL . "/post" ?>" class="button-style purple">
                                                <?=__("Go to dashboard")?>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="features" data-scroll='features'>
            <div class="wrapper">
                <div class="section-heading">
                    <div class="heading-title">
                        <h1><?= __("Make the difference") ?></h1>
                    </div>
                    <div class="desc-text">
                        <p>
                            <?= __("Here are features for you") ?>
                        </p>
                    </div>
                </div>

                <div class="feature-list">
                    <div class="feature">
                        <div class="desc">
                            <div class="icon">
                                <i class="icon icon-layers"></i>
                            </div>

                            <div class="detail desc-text">
                                <p>
                                    <?= __("Unique Design") ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="feature">
                        <div class="desc">
                            <div class="icon">
                                <i class="icon icon-people"></i>
                            </div>

                            <div class="detail desc-text">
                                <p>
                                    <?= __("Multi Instagram Accounts") ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="feature">
                        <div class="desc">
                            <div class="icon">
                                <i class="icon icon-plus"></i>
                            </div>
                            <div class="detail desc-text">
                                <p>
                                    <?= __("Auto Post Content") ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="feature">
                        <div class="desc">
                            <div class="icon">
                                <i class="icon icon-calendar"></i>
                            </div>
                            <div class="detail desc-text">
                                <p>
                                    <?= __("Schedule Posts") ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="feature">
                        <div class="desc">
                            <div class="icon">
                                <i class="icon icon-lock"></i>
                            </div>
                            <div class="detail desc-text">
                                <p>
                                    <?= __("Secure password hash") ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="feature">
                        <div class="desc">
                            <div class="icon">
                                <i class="icon icon-screen-smartphone"></i>
                            </div>
                            <div class="detail desc-text">
                                <p>
                                    <?= __("Mobile Responsive") ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="feature">
                        <div class="desc">
                            <div class="icon">
                                <i class="icon icon-credit-card"></i>
                            </div>
                            <div class="detail desc-text">
                                <p>
                                    <?= __("Payment Gateways") ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="feature">
                        <div class="desc">
                            <div class="icon">
                                <i class="icon icon-emotsmile"></i>
                            </div>
                            <div class="detail desc-text">
                                <p>
                                    <?= __("Emoji Compatibility") ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="link">
                    <a href="<?=APPURL . "/signup"?>" class="button-style purple"><?=__("Get started")?></a>
                </div>
            </div>
        </section>

        <section id="modules">
            <div class="wrapper">
                <div class="clearfix">
                    <div class="details">
                        <div class="heading-title">
                            <h1>
                                <?= __("Nextpost has additional modules to automate some process") ?>
                            </h1>
                        </div>
                        <div class="desc-text">
                            <p>
                                <?= __("Auto Follow, Auto Unfollow, Auto Like, Auto Comment, Auto Direct Message, Auto Repost") ?>
                            </p>
                        </div>
                    </div>

                    <div class="modules-list clearfix">
                        <div class="module">
                            <div class="desc">
                                <div class="icon">
                                    <i class="icon icon-user-following"></i>
                                </div>
                                <div class="title desc-text">
                                    <h1>
                                        <?= __("Auto Follow ") ?>
                                    </h1>
                                </div>
                            </div>
                        </div>

                        <div class="module">
                            <div class="desc">
                                <div class="icon">
                                    <i class="icon icon-user-unfollow"></i>
                                </div>
                                <div class="title desc-text">
                                    <h1>
                                        <?= __("Auto Unfollow ") ?>
                                    </h1>
                                </div>
                            </div>
                        </div>

                        <div class="module">
                            <div class="desc">
                                <div class="icon">
                                    <i class="icon icon-bubbles"></i>
                                </div>
                                <div class="title desc-text">
                                    <h1>
                                        <?= __("Auto Comment ") ?>
                                    </h1>
                                </div>
                            </div>
                        </div>

                        <div class="module">
                            <div class="desc">
                                <div class="icon">
                                    <i class="icon icon-heart"></i>
                                </div>
                                <div class="title desc-text">
                                    <h1>
                                        <?= __("Auto Like ") ?>
                                    </h1>
                                </div>
                            </div>
                        </div>

                        <div class="module">
                            <div class="desc">
                                <div class="icon">
                                    <i class="icon icon-paper-plane"></i>
                                </div>
                                <div class="title desc-text">
                                    <h1>
                                        <?= __("Direct Message ") ?>
                                    </h1>
                                </div>
                            </div>
                        </div>

                        <div class="module">
                            <div class="desc">
                                <div class="icon">
                                    <i class="icon icon-loop"></i>
                                </div>
                                <div class="title desc-text">
                                    <h1>
                                        <?= __("Auto Repost ") ?>
                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="quote">
            <div class="wrapper">
                <div class="quote">
                    <div class="heading-title">
                        <h1><?= __("Insert images from Cloud Drives.")?></h1>
                    </div>

                    <div class="desc-text">
                        <p>
                            <?= __("Nextpost allows you to import images from your <br> Google Drive, Dropbox and OneDrive account") ?>
                        </p>
                    </div>

                    <div class="link">
                        <a href="<?=APPURL . "/signup"?>" class="button-style purple"><?= __("Get started") ?></a>
                    </div>
                </div>
            </div>
        </section>

        <section id="pricing"  data-scroll='pricing'>
            <div class="section-heading">
                <div class="heading-title">
                    <h1><?=__("Pricing")?></h1>
                </div>

                <div class="desc-text">
                    <p>
                        <?=__("How much does it cost to use Nextpost")?>
                    </p>
                </div>
            </div>

            <div class="price-list clearfix">
                <div class="wrapper">
                    <?php
                        $modules = [
                            "auto-follow" => __("Auto Follow"),
                            "auto-unfollow" => __("Auto Unfollow"),
                            "auto-like" => __("Auto Like"),
                            "auto-comment" => __("Auto Comment"),
                            "welcomedm" => __("Auto DM (New Followers)"),
                            "auto-repost" => __("Auto Repost"),
                        ]; 
                    ?>
                    <?php foreach ($Packages->getDataAs("Package") as $p): ?>
                        <div class="price">
                            <div class="price-content">
                                <div class="main-price">
                                    <h1><?= format_price($p->get("monthly_price")) ?></h1>
                                    <p><?= htmlchars($Settings->get("data.currency")) ?>/<?= __("per month") ?></p>
                                </div>

                                <p class="special-discount">
                                    <?php
                                        $total = 12 * $p->get("monthly_price");
                                        $dif = $total - $p->get("annual_price");
                                        $save = $dif * 100 / $total;

                                        if ($save > 0) {
                                            echo __("Save %s when paid annualy", format_price($dif) . " " . htmlchars($Settings->get("data.currency")));
                                        }
                                    ?>
                                </p>

                                <h3 class="pricing-name">
                                    <?= htmlchars($p->get("title")) ?>
                                </h3>

                                <p class="account-count">
                                    <?php
                                        $max = (int)$p->get("settings.max_accounts");
                                        if ($max > 0) {
                                            echo n__("Only 1 account", "Up to %s accounts", $max, $max);
                                        } else if ($max == "-1") {
                                            echo __("Unlimited accounts");
                                        } else {
                                            echo __("Zero accounts");
                                        }
                                    ?>
                                </p>

                                <ul class="feature">
                                    <li class="title"><?=__("Post Types")?>:</li>
                                    <li>
                                        <?php
                                            if ($p->get("settings.post_types.timeline_photo")) {
                                                echo __("Photo") . ',';
                                            } else {
                                                echo "<del>".__("Photo")."</del>,";
                                            }
                                        ?>

                                        <?php
                                            if ($p->get("settings.post_types.timeline_video")) {
                                                echo __("Video");
                                            }else{
                                                echo "<del>".__("Video")."</del>";
                                            }
                                        ?>
                                    </li>

                                    <li>
                                        <?php
                                            $story_photo = $p->get("settings.post_types.story_photo");
                                            $story_video = $p->get("settings.post_types.story_video");
                                        ?>

                                        <?php if ($story_photo && $story_video): ?>
                                            <?=__("Story") . " (" . __("Photo+Video") . ")"?>
                                        <?php elseif ($story_photo): ?>
                                            <?=__("Story") . " (" . __("Photo only") . ")"?>
                                        <?php elseif ($story_video): ?>
                                            <?=__("Story") . " (" . __("Video only") . ")"?>
                                        <?php else: ?>
                                            <del><?=__("Story") . " (" . __("Photo+Video") . ")"?></del>
                                        <?php endif?>
                                    </li>
                                  
                                    <li>
                                        <?php
                                            $album_photo = $p->get("settings.post_types.album_photo");
                                            $album_video = $p->get("settings.post_types.album_video");
                                        ?>

                                        <?php if ($album_photo && $album_video): ?>
                                            <?=__("Album") . " (" . __("Photo+Video") . ")"?>
                                        <?php elseif ($album_photo): ?>
                                            <?=__("Album") . " (" . __("Photo only") . ")"?>
                                        <?php elseif ($album_video): ?>
                                            <?=__("Album") . " (" . __("Video only") . ")"?>
                                        <?php else: ?>
                                            <del><?=__("Album") . " (" . __("Photo+Video") . ")"?></del>
                                        <?php endif?>
                                    </li>
                                </ul>

                                <ul class="feature">
                                    <li class="title"><?=__("Cloud Import")?>:</li>
                                    <li class="cloud-import">
                                        <?php $none = true; ?>
                                        <?php if ($p->get("settings.file_pickers.google_drive")): ?>
                                            <?php $none = false; ?>
                                            <span class="mdi mdi-google-drive" title="Google Drive"></span>
                                        <?php endif ?>

                                        <?php if ($p->get("settings.file_pickers.dropbox")): ?>
                                            <?php $none = false; ?>
                                            <span class="mdi mdi-dropbox" title="Dropbox"></span>
                                        <?php endif ?>

                                        <?php if ($p->get("settings.file_pickers.onedrive")): ?>
                                            <?php $none = false; ?>
                                            <span class="mdi mdi-onedrive" title="OneDrive"></span>
                                        <?php endif ?>

                                        <?php if ($none): ?>
                                            <span><?= __("Not available") ?></span>
                                        <?php endif ?>
                                    </li>
                                </ul>

                                <ul class="feature">
                                    <li class="title"><?= __("Modules") ?></li>

                                    <?php 
                                        $package_modules =  $p->get("settings.modules");
                                        if (!is_array($package_modules)) {
                                            $package_modules = [];
                                        }
                                    ?>
                                    <?php foreach ($modules as $idname => $title): ?>
                                        <li>
                                            <?php if (in_array($idname, $package_modules)): ?>
                                                <?= $title ?>
                                            <?php else: ?>
                                                <del><?= $title ?></del>
                                            <?php endif ?>
                                        </li>
                                    <?php endforeach ?>
                                </ul>

                                <br>

                                <p>
                                    <?php if ($p->get("settings.spintax")): ?>
                                        <?= __("Spintax Support") ?>
                                    <?php else: ?>
                                        <del><?= __("Spintax Support") ?></del>
                                    <?php endif ?>
                                </p>

                                <br>
                                
                                <ul class="feature">
                                    <li class="title"><?=__("Storage")?>:</li>
                                    <li>
                                        <p>
                                            <?php
                                                if ($p->get("settings.storage.total") == "-1") {
                                                    echo __("Unlimited");
                                                } else {
                                                    echo readableFileSize($p->get("settings.storage.total") * 1024 * 1024);
                                                }
                                            ?>
                                        </p>
                                    </li>
                                </ul>

                                <div class="link">
                                    <a href="<?= APPURL . "/" . ($AuthUser ? "renew" : "signup") . "?package=" . $p->get("id") ?>" class="button-style purple"><?= __("Get started") ?></a>
                                </div>
                            </div>
                        </div>
                     <?php endforeach;?>
                </div>
            </div>
        </section>

        <section id="schedule">
            <div class="wrapper">
                <div class="quote">
                    <div class="heading-title">
                        <h1>
                            <?=__("Schedule Posts")?>
                        </h1>
                    </div>

                    <div class="desc-text">
                        <p>
                            <?=__("Nextpost allows you to schedule your posts at a future date to save <br> time. You don't even need to log-in and out of various platforms")?>
                        </p>
                    </div>

                    <div class="link">
                        <a href="<?=APPURL . "/signup"?>" class="button-style purple"><?=__("Get started")?></a>
                    </div>
                </div>
            </div>
        </section>

        <footer>
            <div class="wrapper">
                <div class="clearfix">
                    <div class="brand-logo">
                        <a href="<?= APPURL ?>">
                            <img src="<?= site_settings("logotype") ? site_settings("logotype") : active_theme_url() . "/assets/images/logo.svg"?>"
                                 alt="<?= site_settings("site_name") ?>">
                        </a>
                    </div>

                    <div class="links">
                        <ul>
                            <li>
                                <a href="#" data-scroll='about'><?= __("About") ?></a>
                            </li>
                            <li>
                                <a href="#" data-scroll='features'><?= __("Features") ?></a>
                            </li>
                            <li>
                                <a href="#" data-scroll='pricing'><?= __("Pricing") ?></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>

        <script type="text/javascript" src="<?= active_theme_url() . "/assets/scripts/vendor.js?v=neptun010002" . VERSION?>"></script>
        <script type="text/javascript" src="<?= active_theme_url() . "/assets/scripts/main.js?v=neptun010002" . VERSION?>"></script>
        <?php require_once APPPATH . '/views/fragments/google-analytics.fragment.php';?>
    </body>
</html>