<?php 
    $Integrations = Controller::model("GeneralData", "integrations");
    include 'login.php'; 
?>