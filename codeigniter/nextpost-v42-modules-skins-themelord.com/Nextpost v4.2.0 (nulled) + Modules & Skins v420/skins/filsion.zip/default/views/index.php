<?php if (!defined('APP_VERSION')) die("Yo, what's up?"); ?>
<!doctype html>
<html lang="<?= ACTIVE_LANG ?>">
  <head>
  <!-- 
  Creditos/Desenvolvedor: Cássio Huber
  Base:                   Neptun 4.0
  Compatilidade:          3.0.* - 4.0.*
  Suporte:                cliente.cminfotec.com.br
  Licença:                https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode
  -->
  
    <title><?= site_settings("site_name") ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="<?= site_settings("site_description") ?>">
    <meta name="keywords" content="<?= site_settings("site_keywords") ?>">
    <link rel="stylesheet" href="inc/themes/default/assets/css/owl.carousel.min.css">
    <link rel="icon" href="<?= site_settings("logomark") ? site_settings("logomark") : active_theme_url() . "/assets/images/favicon.ico"?>" type="image/x-icon">
    <link rel="shortcut icon" href="<?= site_settings("logomark") ? site_settings("logomark") : active_theme_url() . "/assets/images/favicon.ico"?>" type="image/x-icon">
    <link rel="stylesheet" href="inc/themes/default/assets/css/animate.min.css">
    <link rel="stylesheet" href="inc/themes/default/assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="inc/themes/default/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="inc/themes/default/assets/css/slicknav.min.css">
    <link rel="stylesheet" href="inc/themes/default/assets/css/animation.css">
    <link rel="stylesheet" href="inc/themes/default/assets/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="inc/themes/default/assets/css/responsive.css">
    <link rel="stylesheet" type="text/css" href="<?= active_theme_url() . "/assets/styles/vendor.css?v=neptun010002" . VERSION ?>">
    <link rel="stylesheet" type="text/css" href="<?= active_theme_url() . "/assets/styles/main.css?v=neptun010002" . VERSION ?>">
  </head>
  <body>
    <!--topo-menu início-->
    <div class="header-area wow fadeInDown header-absolate" id="nav" data-0="position:fixed;" data-top-top="position:fixed;top:0;" data-edge-strategy="set">
        <div class="container">
            <div class="row">
                <div class="col-4 d-block d-lg-none">
                    <div class="mobile-menu"></div>
                </div>
                <div class="col-4 col-lg-2">
                    <div class="logo-area">
                        <img src="<?= site_settings("logotype") ? site_settings("logotype") : active_theme_url() . "/assets/images/logo.svg"?>"</a>
                    </div>
                </div>
                <div class="col-4 col-lg-8 d-none d-lg-block">
                    <div class="main-menu text-center">
                        <nav>
                            <ul id="slick-nav">
                          <ul>
                            <li>
                                <a href="#about" data-scroll='about'><?=__("About")?></a>
                            </li>
                            <li>
                                <a href="#" data-scroll='features'><?=__("Our Tool")?></a>
                            </li>
                            <li>
                                <a href="#pricing" data-scroll='pricing'><?=__("Pricing")?></a>
                            </li>
                            <li>
                                <a href="#" data-scroll='pricing'><?=__("Support")?></a>
                            </li>
                            <li>
                                <a href="#contact" data-scroll='pricing'><?=__("Contact")?></a>
                            </li>

                          </ul>

                  </div>
                </div>
                <div class="col-4 col-lg-2 main-menu text-center">
                <ul>
                    <?php if ($AuthUser): ?>
                                <a href="<?= APPURL . "/profile/" ?>" class="logibtn gradient-btn">
									<?=__("Hi, %s", htmlchars($AuthUser->get("firstname")))?>
                                 </a>
                           <?php else: ?>
                                <li><a href="<?=APPURL . "/login"?>" class="logibtn gradient-btn"><?=__("Sign in")?></a></li>
                                <li><a href="<?=APPURL . "/signup"?>" class="logibtn gradient-btn"><?=__("Register")?></a></li>
                           <?php endif?>
                     </nav>
                  </div>
               </ul> 
            </div>
        </div>
    </div>
    <!--topo-menu fim-->

    <!--boas vindas início-->
    <div class="welcome-area wow fadeInUp" id="home">
        <div id="particles-js"></div>
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6 align-self-center">
                    <div class="welcome-right">
                        <div class="welcome-text">
                             <h1><?= __("Automate your Instagram and get it working for you!") ?>
                            </h1>
                            <h4><?= __("With the Near Post you can work your instagram in a simple and easy way in a single panel, you can manage multiple accounts at the same time") ?></h4>
                        </div>
                        <div class="welcome-btn">
                            <a href="#" class="gradient-btn v2 mr-20"><?=__("Test Free")?></a>
                            <a href="#" class="gradient-btn v2"><?=__("Sign in")?></a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6">
                    <div class="welcome-img">
                        <img src="inc/themes/default/assets/img/welcome-img.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--boas vindas fim-->

    <!--Sobre início-->
    <div class="about-area wow fadeInUp" id="about">
        <div class="space-30"></div>
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="heading">
                        <h5><?= __("Trust our services") ?></h5>
                    </div>
                    <div class="space-30"></div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="logo-carousel owl-carousel text-center">
                        <div class="single-logo-wrapper">
                            <div class="single-item">
                                <img src="inc/themes/default/assets/img/c-logo-1.png" alt="">
                            </div>
                        </div>
                        <div class="single-logo-wrapper">
                            <div class="single-item">
                                <img src="inc/themes/default/assets/img/c-logo-2.png" alt="">
                            </div>
                        </div>
                        <div class="single-logo-wrapper">
                            <div class="single-item">
                                <img src="inc/themes/default/assets/img/c-logo-3.png" alt="">
                            </div>
                        </div>
                        <div class="single-logo-wrapper">
                            <div class="single-item">
                                <img src="inc/themes/default/assets/img/c-logo-4.png" alt="">
                            </div>
                        </div>
                        <div class="single-logo-wrapper">
                            <div class="single-item">
                                <img src="inc/themes/default/assets/img/c-logo-5.png" alt="">
                            </div>
                        </div>
                        <div class="single-logo-wrapper">
                            <div class="single-item">
                                <img src="inc/themes/default/assets/img/c-logo-3.png" alt="">
                            </div>
                        </div>
                        <div class="single-logo-wrapper">
                            <div class="single-item">
                                <img src="inc/themes/default/assets/img/c-logo-2.png" alt="">
                            </div>
                        </div>
                        <div class="single-logo-wrapper">
                            <div class="single-item">
                                <img src="inc/themes/default/assets/img/c-logo-5.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="space-90"></div>
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="about-mid-img">
                        <img src="inc/themes/default/assets/img/about-left.png" alt="">
                    </div>
                </div>
                <div class="col-12 col-md-6 align-self-center">
                    <div class="heading">
                        <h5><?= __("About Nextpost") ?></h5>
                    </div>
                    <div class="about-mid-text">
                        <h1><?= __("A platform created for you and your company!") ?></h1>
                        <div class="space-10"></div>
                        <p><?= __("A complete platform for you and your customers, with it you have the power to manage multiple instagram accounts at the same time and make the system work for you by giving you visibility in the market, created 3 years ago, Nearpost will bring you the best in automation and marketing specialized in social media!") ?></p>
                    </div>
                    <div class="space-30"></div>
                    <a href="#" class="gradient-btn v2 about-btn"> <i class="fa fa-send-o"></i> <?= __("Ask your questions") ?></a>
                </div>
            </div>
        </div>
        <div class="space-90"></div>
    </div>
    <!--Sobre fim-->

    <!--single about area start-->
          <section id="features" data-scroll='features'>
            <div class="wrapper">
                <div class="section-heading">
                    <div class="heading-title">
                        <?= __("Here are features for you") ?>
                    </div>
                    <div class="desc-text">
                        <p>
                            <?= __("Make all the difference") ?>
                        </p>
                    </div>
                </div>

                <div class="feature-list">
                    <div class="feature">
                        <div class="desc">
                            <div class="icon">
                                <i class="icon icon-layers"></i>
                            </div>

                            <div class="detail desc-text">
                                <p>
                                    <?= __("Unique Design") ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="feature">
                        <div class="desc">
                            <div class="icon">
                                <i class="icon icon-people"></i>
                            </div>

                            <div class="detail desc-text">
                                <p>
                                    <?= __("Multiple Instagram accounts") ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="feature">
                        <div class="desc">
                            <div class="icon">
                                <i class="icon icon-plus"></i>
                            </div>
                            <div class="detail desc-text">
                                <p>
                                    <?= __("Auto Post Content") ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="feature">
                        <div class="desc">
                            <div class="icon">
                                <i class="icon icon-calendar"></i>
                            </div>
                            <div class="detail desc-text">
                                <p>
                                    <?= __("Schedule posts") ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="feature">
                        <div class="desc">
                            <div class="icon">
                                <i class="icon icon-lock"></i>
                            </div>
                            <div class="detail desc-text">
                                <p>
                                    <?= __("Secure password hash") ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="feature">
                        <div class="desc">
                            <div class="icon">
                                <i class="icon icon-screen-smartphone"></i>
                            </div>
                            <div class="detail desc-text">
                                <p>
                                    <?= __("Mobile Responsive") ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="feature">
                        <div class="desc">
                            <div class="icon">
                                <i class="icon icon-credit-card"></i>
                            </div>
                            <div class="detail desc-text">
                                <p>
                                    <?= __("Payment Gateways") ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="feature">
                        <div class="desc">
                            <div class="icon">
                                <i class="icon icon-emotsmile"></i>
                            </div>
                            <div class="detail desc-text">
                                <p>
                                    <?= __("Emoji Compatibility") ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="link">
                    <a href="<?=APPURL . "/signup"?>" class="button-style purple"><?=__("Start Now!")?></a>
                </div>
            </div>
        </section>
    <!--single about area end-->
    
    <!--distibution-bg start-->
    <div class="distibution-bg">
    </div>
    <!--distibution-bg end-->

    <!--team-bg-->
    <div class="team-bg">
        <!--Valores Início-->
<section id="pricing"  data-scroll='pricing'>
            <div class="section-heading">
                <div class="heading-title">
                    <h1><?=__("Pricing")?></h1>
                </div>

                <div class="desc-text">
                    <p>
                        <?=__("How much does Nextpost cost?")?>
                    </p>
                </div>
            </div>

            <div class="price-list clearfix">
                <div class="wrapper">
                    <?php
                        $modules = [
                            "auto-follow" => __("Auto Follow"),
                            "auto-unfollow" => __("Auto Unfollow"),
                            "auto-like" => __("Auto Like"),
                            "auto-comment" => __("Auto Comment"),
                            "welcomedm" => __("Auto DM (New Followers)"),
                            "auto-repost" => __("Auto Repost"),
                        ]; 
                    ?>
                    <?php foreach ($Packages->getDataAs("Package") as $p): ?>
                        <div class="price">
                            <div class="price-content">
                                <div class="main-price">
                                    <h1><?= format_price($p->get("monthly_price")) ?></h1>
                                    <p><?= htmlchars($Settings->get("data.currency")) ?>/<?= __("per month") ?></p>
                                </div>

                                <p class="special-discount">
                                    <?php
                                        $total = 12 * $p->get("monthly_price");
                                        $dif = $total - $p->get("annual_price");
                                        $save = $dif * 100 / $total;

                                        if ($save > 0) {
                                            echo __("Save %s when paid annualy", format_price($dif) . " " . htmlchars($Settings->get("data.currency")));
                                        }
                                    ?>
                                </p>

                                <h3 class="pricing-name">
                                    <?= htmlchars($p->get("title")) ?>
                                </h3>

                                <p class="account-count">
                                    <?php
                                        $max = (int)$p->get("settings.max_accounts");
                                        if ($max > 0) {
                                            echo n__("Only 1 account", "Up to %s accounts", $max, $max);
                                        } else if ($max == "-1") {
                                            echo __("Unlimited accounts");
                                        } else {
                                            echo __("Zero accounts");
                                        }
                                    ?>
                                </p>

                                <ul class="feature">
                                    <li class="title"><?=__("Post Types")?>:</li>
                                    <li>
                                        <?php
                                            if ($p->get("settings.post_types.timeline_photo")) {
                                                echo __("Photo") . ',';
                                            } else {
                                                echo "<del>".__("Photo")."</del>,";
                                            }
                                        ?>

                                        <?php
                                            if ($p->get("settings.post_types.timeline_video")) {
                                                echo __("Video");
                                            }else{
                                                echo "<del>".__("Video")."</del>";
                                            }
                                        ?>
                                    </li>

                                    <li>
                                        <?php
                                            $story_photo = $p->get("settings.post_types.story_photo");
                                            $story_video = $p->get("settings.post_types.story_video");
                                        ?>

                                        <?php if ($story_photo && $story_video): ?>
                                            <?=__("Story") . " (" . __("Photo+Video") . ")"?>
                                        <?php elseif ($story_photo): ?>
                                            <?=__("Story") . " (" . __("Photo only") . ")"?>
                                        <?php elseif ($story_video): ?>
                                            <?=__("Story") . " (" . __("Video only") . ")"?>
                                        <?php else: ?>
                                            <del><?=__("Story") . " (" . __("Photo+Video") . ")"?></del>
                                        <?php endif?>
                                    </li>
                                  
                                    <li>
                                        <?php
                                            $album_photo = $p->get("settings.post_types.album_photo");
                                            $album_video = $p->get("settings.post_types.album_video");
                                        ?>

                                        <?php if ($album_photo && $album_video): ?>
                                            <?=__("Album") . " (" . __("Photo+Video") . ")"?>
                                        <?php elseif ($album_photo): ?>
                                            <?=__("Album") . " (" . __("Photo only") . ")"?>
                                        <?php elseif ($album_video): ?>
                                            <?=__("Album") . " (" . __("Video only") . ")"?>
                                        <?php else: ?>
                                            <del><?=__("Album") . " (" . __("Photo+Video") . ")"?></del>
                                        <?php endif?>
                                    </li>
                                </ul>

                                <ul class="feature">
                                    <li class="title"><?=__("Cloud Import")?>:</li>
                                    <li class="cloud-import">
                                        <?php $none = true; ?>
                                        <?php if ($p->get("settings.file_pickers.google_drive")): ?>
                                            <?php $none = false; ?>
                                            <span class="mdi mdi-google-drive" title="Google Drive"></span>
                                        <?php endif ?>

                                        <?php if ($p->get("settings.file_pickers.dropbox")): ?>
                                            <?php $none = false; ?>
                                            <span class="mdi mdi-dropbox" title="Dropbox"></span>
                                        <?php endif ?>

                                        <?php if ($p->get("settings.file_pickers.onedrive")): ?>
                                            <?php $none = false; ?>
                                            <span class="mdi mdi-onedrive" title="OneDrive"></span>
                                        <?php endif ?>

                                        <?php if ($none): ?>
                                            <span><?= __("Not available") ?></span>
                                        <?php endif ?>
                                    </li>
                                </ul>

                                <ul class="feature">
                                    <li class="title"><?= __("Modules") ?></li>

                                    <?php 
                                        $package_modules =  $p->get("settings.modules");
                                        if (!is_array($package_modules)) {
                                            $package_modules = [];
                                        }
                                    ?>
                                    <?php foreach ($modules as $idname => $title): ?>
                                        <li>
                                            <?php if (in_array($idname, $package_modules)): ?>
                                                <?= $title ?>
                                            <?php else: ?>
                                                <del><?= $title ?></del>
                                            <?php endif ?>
                                        </li>
                                    <?php endforeach ?>
                                </ul>

                                <br>

                                <p>
                                    <?php if ($p->get("settings.spintax")): ?>
                                        <?= __("Spintax Support") ?>
                                    <?php else: ?>
                                        <del><?= __("Spintax Support") ?></del>
                                    <?php endif ?>
                                </p>

                                <br>
                                
                                <ul class="feature">
                                    <li class="title"><?=__("Storage")?>:</li>
                                    <li>
                                        <p>
                                            <?php
                                                if ($p->get("settings.storage.total") == "-1") {
                                                    echo __("Unlimited");
                                                } else {
                                                    echo readableFileSize($p->get("settings.storage.total") * 1024 * 1024);
                                                }
                                            ?>
                                        </p>
                                    </li>
                                </ul>

                                <div class="link">
                                    <a href="<?= APPURL . "/" . ($AuthUser ? "renew" : "signup") . "?package=" . $p->get("id") ?>" class="button-style purple"><?= __("Get started") ?></a>
                                </div>
                            </div>
                        </div>
                     <?php endforeach;?>
                </div>
            </div>
        </section>
        <!--Valores Fim-->

        <!--apps area start-->
        <div class="apps-area wow fadeInUp section-padding" id="apps">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-5 offset-1 align-self-center">
                        <div class="heading">
                            <h5><?=__("MOBILE APPLICATION")?></h5>
                            <div class="space-10"></div>
                            <h1><?=__("Accompany from anywhere!")?></h1>
                            <div class="space-20"></div>
                            <p><?=__("In addition to the web service our clients can follow all the processes via Mobile Application and if you want you can make your programming there too")?> </p>
                            <p><?=__("this is just one more facility we offer to our customers, download it now!")?></p>
                        </div>
                        <div class="space-30"></div>
                        <a href="#" class="gradient-btn apps-btn"> <i class="zmdi zmdi-google-play"></i>Google Playstore</a>

                        <a href="#" class="gradient-btn apps-btn apps-btn-2"> <i class="zmdi zmdi-apple"></i>Apple Appstore</a>
                    </div>
                    <div class="col-12 col-lg-5 offset-1">
                        <div class="apps-img">
                            <img src="inc/themes/default/assets/img/Mobile.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--apps area end-->

        <!--faq area start-->
        <div class="faq-area wow fadeInUp" id="faq">
            <div class="container">
                <div class="row">
                    <div class="col-12 text-center">
                    <div class="heading">
                        <h5>F.A.Q</h5>
                        <div class="space-10"></div>
                        <h1><?=__("Common questions")?></h1>
                    </div>
                    <div class="space-60"></div>
                </div>
                </div>
                <div class="row">
                    <div class="col-12 text-center">
                        <div class="faq-list">
                            <ul class="nav nav-pills" id="pills-tab">
                                <li><a class="active" data-toggle="pill" href="#one"><?=__("All")?></a></li>
                                <li><a data-toggle="pill" href="#two"><?=__("My account")?></a></li>
                                <li><a data-toggle="pill" href="#three"><?=__("Add My Account")?></a></li>
                                <li><a data-toggle="pill" href="#four"><?=__("Alerts")?></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="space-50"></div>
            </div>
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="one">
                        <div class="container-fluid">
                            <div class="faq-carousel owl-carousel">
                                <div class="single-faq">
                                    <h4>Edit 1</h4>
                                    <div class="space-20"></div>
                                    <p>Swimming hundreds of feet beneath the ocean’s surface in many parts of the world are prolific architects called giant larvaceans. These zooplankton are not particularly giant themselves (they resemble tadpoles and are about the size of a pinkie finger), but every day.</p>
                                    <div class="space-20"></div>
                                    <a href="#" class="readmore-btn"><i class="fa fa-angle-right"></i>readmore</a>
                                </div>
                                <div class="single-faq">
                                    <h4>Edit 2</h4>
                                    <div class="space-20"></div>
                                    <p>Swimming hundreds of feet beneath the ocean’s surface in many parts of the world are prolific architects called giant larvaceans. These zooplankton are not particularly giant themselves (they resemble tadpoles and are about the size of a pinkie finger), but every day.</p>
                                    <div class="space-20"></div>
                                    <a href="#" class="readmore-btn"><i class="fa fa-angle-right"></i>readmore</a>
                                </div>
                                <div class="single-faq">
                                    <h4>Edit 3</h4>
                                    <div class="space-20"></div>
                                    <p>Swimming hundreds of feet beneath the ocean’s surface in many parts of the world are prolific architects called giant larvaceans. These zooplankton are not particularly giant themselves (they resemble tadpoles and are about the size of a pinkie finger), but every day</p>
                                    <div class="space-20"></div>
                                    <a href="#" class="readmore-btn"><i class="fa fa-angle-right"></i>readmore</a>
                                </div>
                                <div class="single-faq">
                                    <h4>Edit 4</h4>
                                    <div class="space-20"></div>
                                    <p>Swimming hundreds of feet beneath the ocean’s surface in many parts of the world are prolific architects called giant larvaceans. These zooplankton are not particularly giant themselves (they resemble tadpoles and are about the size of a pinkie finger), but every day</p>
                                    <div class="space-20"></div>
                                    <a href="#" class="readmore-btn"><i class="fa fa-angle-right"></i>readmore</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="two">
                        <div class="container-fluid">
                            <div class="faq-carousel owl-carousel">
                                <div class="single-faq">
                                    <h4>Edit 1</h4>
                                    <div class="space-20"></div>
                                    <p>Swimming hundreds of feet beneath the ocean’s surface in many parts of the world are prolific architects called giant larvaceans. These zooplankton are not particularly giant themselves (they resemble tadpoles and are about the size of a pinkie finger), but every day.</p>
                                    <div class="space-20"></div>
                                    <a href="#" class="readmore-btn"><i class="fa fa-angle-right"></i>readmore</a>
                                </div>
                                <div class="single-faq">
                                    <h4>Edit 2</h4>
                                    <div class="space-20"></div>
                                    <p>Swimming hundreds of feet beneath the ocean’s surface in many parts of the world are prolific architects called giant larvaceans. These zooplankton are not particularly giant themselves (they resemble tadpoles and are about the size of a pinkie finger), but every day.</p>
                                    <div class="space-20"></div>
                                    <a href="#" class="readmore-btn"><i class="fa fa-angle-right"></i>readmore</a>
                                </div>
                                <div class="single-faq">
                                    <h4>Edit 3</h4>
                                    <div class="space-20"></div>
                                    <p>Swimming hundreds of feet beneath the ocean’s surface in many parts of the world are prolific architects called giant larvaceans. These zooplankton are not particularly giant themselves (they resemble tadpoles and are about the size of a pinkie finger), but every day</p>
                                    <div class="space-20"></div>
                                    <a href="#" class="readmore-btn"><i class="fa fa-angle-right"></i>readmore</a>
                                </div>
                                <div class="single-faq">
                                    <h4>Edit 4</h4>
                                    <div class="space-20"></div>
                                    <p>Swimming hundreds of feet beneath the ocean’s surface in many parts of the world are prolific architects called giant larvaceans. These zooplankton are not particularly giant themselves (they resemble tadpoles and are about the size of a pinkie finger), but every day</p>
                                    <div class="space-20"></div>
                                    <a href="#" class="readmore-btn"><i class="fa fa-angle-right"></i>readmore</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="three">
                        <div class="container-fluid">
                            <div class="faq-carousel owl-carousel">
                                <div class="single-faq">
                                    <h4>Edit 1</h4>
                                    <div class="space-20"></div>
                                    <p>Swimming hundreds of feet beneath the ocean’s surface in many parts of the world are prolific architects called giant larvaceans. These zooplankton are not particularly giant themselves (they resemble tadpoles and are about the size of a pinkie finger), but every day.</p>
                                    <div class="space-20"></div>
                                    <a href="#" class="readmore-btn"><i class="fa fa-angle-right"></i>readmore</a>
                                </div>
                                <div class="single-faq">
                                    <h4>Edit 2</h4>
                                    <div class="space-20"></div>
                                    <p>Swimming hundreds of feet beneath the ocean’s surface in many parts of the world are prolific architects called giant larvaceans. These zooplankton are not particularly giant themselves (they resemble tadpoles and are about the size of a pinkie finger), but every day.</p>
                                    <div class="space-20"></div>
                                    <a href="#" class="readmore-btn"><i class="fa fa-angle-right"></i>readmore</a>
                                </div>
                                <div class="single-faq">
                                    <h4>Edit 3</h4>
                                    <div class="space-20"></div>
                                    <p>Swimming hundreds of feet beneath the ocean’s surface in many parts of the world are prolific architects called giant larvaceans. These zooplankton are not particularly giant themselves (they resemble tadpoles and are about the size of a pinkie finger), but every day</p>
                                    <div class="space-20"></div>
                                    <a href="#" class="readmore-btn"><i class="fa fa-angle-right"></i>readmore</a>
                                </div>
                                <div class="single-faq">
                                    <h4>Edit 4</h4>
                                    <div class="space-20"></div>
                                    <p>Swimming hundreds of feet beneath the ocean’s surface in many parts of the world are prolific architects called giant larvaceans. These zooplankton are not particularly giant themselves (they resemble tadpoles and are about the size of a pinkie finger), but every day</p>
                                    <div class="space-20"></div>
                                    <a href="#" class="readmore-btn"><i class="fa fa-angle-right"></i>readmore</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="four">
                        <div class="container-fluid">
                            <div class="faq-carousel owl-carousel">
                                <div class="single-faq">
                                    <h4>Edit 1</h4>
                                    <div class="space-20"></div>
                                    <p>Swimming hundreds of feet beneath the ocean’s surface in many parts of the world are prolific architects called giant larvaceans. These zooplankton are not particularly giant themselves (they resemble tadpoles and are about the size of a pinkie finger), but every day.</p>
                                    <div class="space-20"></div>
                                    <a href="#" class="readmore-btn"><i class="fa fa-angle-right"></i>readmore</a>
                                </div>
                                <div class="single-faq">
                                    <h4>Edit 2</h4>
                                    <div class="space-20"></div>
                                    <p>Swimming hundreds of feet beneath the ocean’s surface in many parts of the world are prolific architects called giant larvaceans. These zooplankton are not particularly giant themselves (they resemble tadpoles and are about the size of a pinkie finger), but every day.</p>
                                    <div class="space-20"></div>
                                    <a href="#" class="readmore-btn"><i class="fa fa-angle-right"></i>readmore</a>
                                </div>
                                <div class="single-faq">
                                    <h4>Edit 3</h4>
                                    <div class="space-20"></div>
                                    <p>Swimming hundreds of feet beneath the ocean’s surface in many parts of the world are prolific architects called giant larvaceans. These zooplankton are not particularly giant themselves (they resemble tadpoles and are about the size of a pinkie finger), but every day</p>
                                    <div class="space-20"></div>
                                    <a href="#" class="readmore-btn"><i class="fa fa-angle-right"></i>readmore</a>
                                </div>
                                <div class="single-faq">
                                    <h4>Edit 4</h4>
                                    <div class="space-20"></div>
                                    <p>Swimming hundreds of feet beneath the ocean’s surface in many parts of the world are prolific architects called giant larvaceans. These zooplankton are not particularly giant themselves (they resemble tadpoles and are about the size of a pinkie finger), but every day</p>
                                    <div class="space-20"></div>
                                    <a href="#" class="readmore-btn"><i class="fa fa-angle-right"></i>readmore</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <div class="space-90"></div>
        </div>
        <!--faq area end-->
    </div>
    <!--team bg area end-->

    <!--community area start-->
    <div class="community-area wow fadeInUp section-padding" id="contact">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="heading">
                        <h5><?=__("Follow our networks")?></h5>
                        <div class="space-10"></div>
                        <h1><?=__("Follow Us")?></h1>
                    </div>
                <div class="space-60"></div>
                </div>
            </div>
            <div class="row">
                <div class="col-6 col-lg">
                    <div class="single-community big-social">
                        <a class="google-plus" href="#"><i class="fa fa-google-plus"></i></a>
                    </div>
                </div>
                <div class="col-6 col-lg">
                    <div class="single-community mid-social">
                        <a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a>
                    </div>
                    <div class="single-community">
                        <a class="dribbble" href="#"><i class="fa fa-dribbble"></i></a>
                    </div>
                </div>
                <div class="col-6 col-lg">
                    <div class="single-community">
                        <a class="github" href="#"><i class="fa fa-instagram"></i></a>
                    </div>
                    <div class="single-community mid-social">
                        <a class="behance" href="#"><i class="fa fa-behance"></i></a>
                    </div>
                </div>
                <div class="col-6 col-lg">
                    <div class="single-community big-social">
                        <a class="youtube" href="#"><i class="fa fa-youtube"></i></a>
                    </div>
                </div>
                <div class="col-6 col-lg">
                    <div class="single-community mid-social">
                        <a class="twitter" href="#"><i class="fa fa-twitter"></i></a>
                    </div>
                    <div class="single-community">
                        <a class="flickr" href="#"><i class="fa fa-flickr"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--community area end-->

    <!--footer area start-->
    <div class="footera-area section-padding wow fadeInDown">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-footer">
                        <div class="logo-area footer">
                            <a href="/"><img src="<?= site_settings("logotype") ? site_settings("logotype") : active_theme_url() . "/assets/images/logo.svg"?>"</a>
                            </a>
                        </div>
                        <div class="space-20"></div>
                        <p><?=__("Nextpost is a tool created to facilitate the Administration and Automation of Instagram, we seek to make life easier for our customers and we are in the market for 3 years, making your life easier.")?> </p>
                        <div class="space-10"></div>
                        <p>Copyright &copy; 2018 - NearPost</p>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-lg-2">
                    <div class="single-footer">
                        <ul>
                            <li><a href="#about" data-scroll='about'><?=__("About")?></a></li>
                            <li><a href="#" data-scroll='features'><?=__("Our Tool")?></a></li>
                            <li><a href="#pricing" data-scroll='pricing'><?=__("Pricing")?></a></li>
                            <li><a href="#contact" data-scroll='pricing'><?=__("Contact")?></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-6 col-lg-2">
                    <div class="single-footer">
                        <ul>
                            <li><a href="#about" data-scroll='about'><?=__("About")?></a></li>
                            <li><a href="#" data-scroll='features'><?=__("Our Tool")?></a></li>
                            <li><a href="#pricing" data-scroll='pricing'><?=__("Pricing")?></a></li>
                            <li><a href="#contact" data-scroll='pricing'><?=__("Contact")?></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-footer">
                        <p><?=__("Receive our news")?></p>
                        <div class="space-20"></div>
                        <div class="footer-form">
                            <form action="#">
                                <input type="email" placeholder="e-mail">
                                <a href="" class="gradient-btn subscribe">GO</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--footer area end-->
                            
    <script src="inc/themes/default/assets/js/jquery-2.2.4.min.js"></script>
    <script src="inc/themes/default/assets/js/popper.js"></script>
    <script src="inc/themes/default/assets/js/owl.carousel.min.js"></script>
    <script src="inc/themes/default/assets/js/wow.min.js"></script>
    <script src="inc/themes/default/assets/js/bootstrap.min.js"></script>
    <script src="inc/themes/default/assets/js/skrollr.min.js"></script>
    <script src="inc/themes/default/assets/js/jquery.slicknav.min.js"></script>
    <script src="inc/themes/default/assets/js/particles.min.js"></script>
    <script src="inc/themes/default/assets/js/main.js"></script>
    <script type="text/javascript" src="<?= active_theme_url() . "/assets/scripts/vendor.js?v=neptun010002" . VERSION?>"></script>
    <script type="text/javascript" src="<?= active_theme_url() . "/assets/scripts/main.js?v=neptun010002" . VERSION?>"></script>
    <?php require_once APPPATH . '/views/fragments/google-analytics.fragment.php';?>
  </body>
</html>