<?php if (!defined('APP_VERSION')) die("Yo, what's up?"); ?>
<!DOCTYPE html>
<html class="no-js" lang="<?= ACTIVE_LANG ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>
        <meta name="theme-color" content="#fff">

        <meta name="description" content="<?= site_settings("site_description") ?>">
        <meta name="keywords" content="<?= site_settings("site_keywords") ?>">

        <link rel="icon" href="<?= site_settings("logomark") ? site_settings("logomark") : active_theme_url() . "/assets/images/favicon.ico"?>" type="image/x-icon">
        <link rel="shortcut icon" href="<?= site_settings("logomark") ? site_settings("logomark") : active_theme_url() . "/assets/images/favicon.ico"?>" type="image/x-icon">
        
        <link rel="stylesheet" type="text/css" href="<?= active_theme_url() . "/assets/styles/vendor.css?v=neptun010002" . VERSION ?>">
        <link rel="stylesheet" type="text/css" href="<?= active_theme_url() . "/assets/styles/main.css?v=neptun010002" . VERSION ?>">

        <title><?= site_settings("site_name") ?></title>
    </head>

    <body>
        <?php $action = \Input::post("action"); ?>
        <section id="signin">
            <div class="page-holder clearfix">
                <div class="signin side float-left flex flex-center flex-middle" data-active="<?= $action == "login" ? "true" : ($action=="signup" || $Route->target == "Signup" ? "false" : "") ?>">
                    <div class="signin-form">
                        <form action="<?= APPURL."/login" ?>" method="POST" autocomplete="off">
                            <input type="hidden" name="action" value="login">
                            <?php if (Input::post("action") == "login"): ?>
                                <div class="form-result">
                                    <div class="color-danger">
                                        <span class="mdi mdi-close"></span>
                                        <?= __("Login credentials didn't match!") ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="social-networks">
                                <?php if($Integrations->get("data.facebook.app_id") && $Integrations->get("data.facebook.app_secret")): ?>
                                <a class="fbloginbtn" href="javascript:void(0)" data-social='facebook'>
                                    <i class="mdi mdi-facebook-box"></i>
                                    <span><?= __("Login with Facebook") ?></span>
                                </a>
                                <?php endif; ?>
                            </div>

                            <div class="form">
                                <div class="form-element">
                                    <div class="input-wrapper material-style">
                                        <input type="text" 
                                               class="input-style" 
                                               id="username" 
                                               name="username" 
                                               value="<?= htmlchars(Input::Post("username")) ?>">
                                        <label for="username" class="placeholder">
                                                <?= __("Email address") ?>
                                        </label>
                                    </div>
                                </div>
                                <div class="form-element">
                                    <div class="input-wrapper  material-style">
                                        <input 
                                        type="password"
                                        class="input-style"
                                        id="password"
                                        name="password">
                                        <label for="password" class="placeholder">
                                                    <?= __("Password") ?>
                                        </label>
                                    </div>
                                </div>
                                <div class="form-element submit">
                                    <button class="button-style purple" type="submit">
                                        <?= __('Sign in') ?>
                                    </button>
                                </div>
                                <div class="reset-pass">
                                    <a href="<?= APPURL."/recovery" ?>"><?= __("Forgot your password?") ?></a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="signup side float-left flex flex-start flex-middle" data-active="<?= $action == "signup" || $Route->target == "Signup" ? "true" : ($action=="login" ? "false" : "") ?>">
                    <div class="details">
                        <div class="heading-title">
                            <h1> <?= __("Sign up") ?></h1>
                        </div>
                        <div class='extra'>
                            <div class="desc-text">
                                <p><?= __("It's absolutely free and takes <br> less than 30 seconds.") ?></p>
                            </div>                        
                            <button class="sign-up button-style"><?= __("Sign up") ?></button>
                        </div>
                    </div>

                    <div class="signup-form">
                        <div class="form-holder">
                            <div class="title">
                                <h1><?= __("Sign up") ?></h1>
                            </div>

                            <div class="form">
                                <form action="<?= APPURL."/signup" ?>" method="POST" autocomplete="off">
                                <input type="hidden" name="action" value="signup">
                                <?php if (!empty($FormErrors)): ?>
                                    <div class="form-result">
                                        <?php foreach ($FormErrors as $error): ?>
                                            <div class="color-danger">
                                                <span class="mdi mdi-close"></span>
                                                <?= $error ?>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>

                                <div class="form-element">
                                    <div class="input-wrapper material-style">
                                        <input type="text" class="input-style <?= Input::Post("firstname") ? "has-value" : "" ?>" name="firstname" value="<?= htmlchars(Input::Post("firstname")) ?>">
                                        <label class="placeholder"><?= __('Firstname') ?></label>
                                    </div>
                                </div>

                                <div class="form-element">
                                    <div class="input-wrapper material-style">
                                        <input type="text" class="input-style <?= Input::Post("lastname") ? "has-value" : "" ?>" name="lastname" value="<?= htmlchars(Input::Post("lastname")) ?>">
                                        <label class="placeholder"><?= __('Lastname') ?></label>
                                    </div>
                                </div>

                                <div class="form-element">
                                    <div class="input-wrapper  material-style">
                                        <input type="email" name="email" class="input-style <?= Input::Post("email") ? "has-value" : "" ?>" value="<?= htmlchars(Input::Post("email")) ?>" value="<?= htmlchars(Input::Post("email")) ?>">
                                        <label class="placeholder"><?= __("Email") ?></label>
                                    </div>
                                </div>

                                <div class="form-element">
                                    <div class="input-wrapper  material-style">
                                        <input type="password" class="input-style" name="password">
                                        <label class="placeholder"><?= __("Password") ?></label>
                                    </div>
                                </div>

                                <div class="form-element">
                                    <div class="input-wrapper  material-style">
                                        <input type="password" class="input-style" name="password-confirm">
                                        <label class="placeholder"><?= __("Confirm password") ?></label>
                                    </div>
                                </div>

                                <div class="form-element">
                                    <div class="input-wrapper  material-style dropdown timezone dropdown-click" data-role='list-holder'>
                                        <?php 
                                            $tz = $IpInfo->timezone;
                                            $timezones = getTimezones();

                                            $active_timezone = "";
                                            if (isset($timezones[$tz])) {
                                                $active_timezone = $timezones[$tz];   
                                            }

                                            if (\Input::post("timezone")) {
                                                $active_timezone = \Input::post("timezone");
                                            }
                                        ?>

                                        <input type="text" class="input-style dropdown-append-value timezone-value <?= $active_timezone ? "has-value" : "" ?>" data-role="value"  value="<?= $active_timezone ?>" name="timezone">
                                        <label class="placeholder"><?= __("Select your timezone") ?></label>

                                        <div class="dropdown-list js-timezone-dropdown timezone-list">
                                            <ul data-role='list'>
                                                <?php foreach ($timezones as $k => $v): ?>
                                                    <li>
                                                        <a href="#"  data-list-item  data-value='<?= $k ?>'><?= $v ?></a>
                                                    </li>
                                                <?php endforeach; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-element submit">
                                    <button class="button-style purple" type="submit">
                                        <?= __("Get Started") ?>
                                    </button>
                                </div>
                            </form>
                            </div>

                            <div class="agreement">
                                <p>
                                    <?= __("By creating an acount you agree to our terms of service.") ?><br>
                                    <a href="<?= APPURL."/login" ?>"><?= __("Already have an account?") ?></a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <script type="text/javascript" src="<?= active_theme_url() . "/assets/scripts/vendor.js?v=neptun010002" . VERSION?>"></script>
        <script type="text/javascript" src="<?= active_theme_url() . "/assets/scripts/main.js?v=neptun010002" . VERSION?>"></script>
        <script type="text/javascript" charset="utf-8">
            $(function() {
                <?php if($Integrations->get("data.facebook.app_id") && $Integrations->get("data.facebook.app_secret")): ?>
                    NeptuneTheme.FacebookLogin('<?= htmlchars($Integrations->get("data.facebook.app_id")) ?>', '<?= APPURL."/login" ?>');
                <?php endif; ?>
            });
        </script>
        <?php require_once APPPATH . '/views/fragments/google-analytics.fragment.php';?>
    </body>
</html>