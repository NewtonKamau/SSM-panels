(function(){
    'use strict';

    var affiliateApp = angular.module('affiliateApp', ['angular.filter','toaster', 'ngAnimate'])
    .filter('dateFormat', function myDateFormat($filter){
        return function(text){
          //if(typeof text == "undefined"){text = "";}
          var  tempdate= new Date(text.replace(/-/g,"/"));
          return $filter('date')(tempdate, "dd-MM-yyyy");
        }
      })
    .controller('UserController', function($scope, $http, $rootScope, $location ,$filter, $interval,toaster) {

            $scope.dashboard_table = "withdraw";
            $scope.customerinfo = {};
            $scope.payout_settings = {};
            $scope.payout_settings.payoutmethod = 'paypal';
            $scope.pagedWithdraw = [];
            $scope.pagedTimeline = [];

            $scope.menusettings = {};
            $scope.menusettings.menu = "withdraw";

            $scope.menusettings_user = {};
            $scope.menusettings_user.menu = "payout";

            $scope.orderByDate = function(item) {
                var parts = item.date.split('.');
                var number = parseInt(parts[2] + parts[1] + parts[0]);
                return -number;
            };


      $scope.getData = function() {

              $scope.editLink = {};

              $http({
                 method: 'GET',
                 url: $location.absUrl() + "/req/getRefs"
              }).then(function (data){

            if(typeof data.data.settings != 'undefined') {
              $scope.settings = data.data.settings;
              $scope.currency = $scope.settings.currency;
            }else{
              $scope.settings = {}
            };

            if(!data.data.isAdmin){

              if(typeof data.data.refs != 'undefined') {$scope.pagedRefs = data.data.refs}else{$scope.pagedRefs = {}};
              if(typeof data.data.balance != 'undefined') {$scope.balance = data.data.balance}else{$scope.balance = {}};
              if(typeof data.data.withdraw != 'undefined') {$scope.withdraw = data.data.withdraw}else{$scope.withdraw = {}};
              if(typeof data.data.lw != 'undefined') {$scope.lw = data.data.lw}else{$scope.lw = {}};
              if(typeof data.data.last_withdraw != 'undefined') {$scope.last_withdraw = data.data.last_withdraw}else{$scope.last_withdraw = {}};
              if(typeof data.data.user_settings != 'undefined') {
              $scope.user_settings = data.data.user_settings;
              if($scope.user_settings.linkpage == "true"){$scope.user_settings.linkpage = true;}else{$scope.user_settings.linkpage = false;}
              if($scope.user_settings.picture == "true"){$scope.user_settings.picture = true;}else{$scope.user_settings.picture = false;}
              if($scope.user_settings.reflink == "true"){$scope.user_settings.reflink = true;}else{$scope.user_settings.reflink = false;}
              }else{$scope.user_settings = {}};
              if(typeof data.data.user_links != 'undefined') {$scope.user_links = data.data.user_links}else{$scope.user_links = {}};


              if(typeof $scope.pagedRefs != 'undefined') {
              $scope.totalItems = $scope.pagedRefs.length;
              $scope.totalRefs = $scope.pagedRefs.length;
            }else{
              $scope.totalItems = 0;
              $scope.totalRefs = 0;
            }
              $scope.totalCommissions=0;

              if($scope.balance.total_spent == null){
                $scope.balance.total_spent = 0;
              }

              $scope.balance.pagedPayments = data.data.paymentlist;
              $scope.balance.payout_min = data.data.payout_min;

              angular.forEach($scope.pagedRefs, function(value, key) {
                $scope.totalCommissions = $scope.totalCommissions + parseInt(value.commissions);
                value.icon = "sli-user-follow";
                value.follow = true;
              });

              angular.forEach(data.data.timeline, function(value, key) {
                var tempdata = JSON.parse(value.data);
                value.package = tempdata.package.title;

                if(value.gateway == "paypal"){
                  value.icon = "sli-paypal";
                }else{
                  value.icon = "sli-credit-card";
                }
              });

              angular.forEach($scope.withdraw, function(value, key) {
                if(value.status == "pending"){
                  value.icon = "sli-refresh";
                  value.firstname = "Withdraw ";
                  value.lastname = "requested";
                  value.color ="red";
                  value.withdraw = true;
                }else if(value.status == "declined"){
                  value.icon = "sli-close";
                  value.firstname = "Withdraw ";
                  value.lastname = "declined";
                  value.withdraw = true;
                  value.amount = 0;
                  value.color ="black";
                }else if(value.status = "paid"){
                  value.icon = "sli-check";
                  value.firstname = "Withdraw ";
                  value.lastname = "approved";
                  value.withdraw = true;
                  value.color ="red";
                }
              });

              if(typeof data.data.timeline != 'undefined') {$scope.pagedTimeline = data.data.timeline.concat($scope.pagedRefs);}
              if(typeof $scope.withdraw != 'undefined') {$scope.pagedTimeline =$scope.pagedTimeline.concat($scope.withdraw);}

            }else{
              $scope.paymentstotal = 0;
              $scope.customerinfo = data.data.customerinfo;
              $scope.affiliateinfo = data.data.affiliate;
              $scope.pagedWithdraw = data.data.withdraw;
              $scope.paymentstotal = data.data.payments_total;
              $scope.pagedAffiliates = data.data.affiliatelist;
              $scope.pagedPayments = data.data.paymentlist;
              $scope.payout_min = $scope.settings.payout_min;

              if(typeof data.data.user_settings != 'undefined') {
              $scope.user_settings = data.data.user_settings;
              if($scope.user_settings.linkpage == "true"){$scope.user_settings.linkpage = true;}else{$scope.user_settings.linkpage = false;}
              if($scope.user_settings.picture == "true"){$scope.user_settings.picture = true;}else{$scope.user_settings.picture = false;}
              if($scope.user_settings.reflink == "true"){$scope.user_settings.reflink = true;}else{$scope.user_settings.reflink = false;}
              }else{$scope.user_settings = {}};
              if(typeof data.data.user_links != 'undefined') {$scope.user_links = data.data.user_links}else{$scope.user_links = {}};

              angular.forEach($scope.pagedPayments, function(value, key) {
                var tempdata = JSON.parse(value.data);

                value.package = tempdata.package.title;

                if(value.payment_gateway == "paypal"){
                  value.icon = "sli-paypal";
                }else{
                  value.icon = "sli-credit-card";
                }
              });

            }

        },function (error){
            $scope.error = data.msg;
        });


      }

      $scope.withdraw_action = function(){

        if($scope.lw.status != 'pending'){

          $scope.withdraw_request();

        }else{

          $scope.withdrawCancel();

        }

      }

      $scope.withdraw_request = function() {

        var error = {};
            error.state = true;
            error.title = "Withdraw Error"
            error.msg = "";

        // check for minimal amount

        if($scope.balance.actual > $scope.settings.payout_min){

            //check fo Payoutinfos
            if($scope.user_settings.payout_method == 'paypal'){

              var expressionEmail = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
              var regexEmail = new RegExp(expressionEmail);

              if(typeof $scope.user_settings.payout_paypal != "undefined"){

                if($scope.user_settings.payout_paypal.match(regexEmail)){
                  error.state = false;
                }else{
                error.msg = "Paypal Email has wrong format.";
                }

              }else{
              error.msg = "Paypal Email is not defined.";
              }

            }else if($scope.user_settings.payout_method == 'bankaccount'){

              if(typeof $scope.user_settings.payout_bankinfo != "undefined"){
                error.state = false;
              }else{
              error.msg = "Bankaccount Information is needet.";
              }

            }else{
              error.msg = "Plz choose a Payout method";
              $scope.menu = "settings_user";
            }
        }else{
          error.msg = "Minimal Payment Amount not meet.";
        }


        if(!error.state){

            $http.post($location.absUrl() + "/req/withdraw", {
                'lastwithdraw': $scope.last_withdraw,
                'amount': $scope.balance.actual
            })
                .success(function(data, status, headers, config) {

                  if(data.result){
                  $scope.getData();
                  toaster.pop({
                                  type: 'success',
                                  title: 'Withdraw',
                                  body: "Withdraw requested.",
                                  timeout: 3000
                              });
                  }else{

                    toaster.pop({
                                    type: 'warning',
                                    title: 'Balance to low',
                                    body: data.msg,
                                    timeout: 3000
                                });

                  }

                })
                .error(function(data, status, headers, config) {
                });
        }else{
          toaster.pop({
                          type: 'error',
                          title: 'Withdraw error',
                          body: error.msg,
                          timeout: 3000
                      });
        }


      }

      $scope.withdrawCancel = function() {
          $http.post($location.absUrl() + "/req/withdrawCancel", {
              'cancelWithdraw': JSON.stringify($scope.lw)
          })
              .success(function(data, status, headers, config) {
                $scope.getData();
                toaster.pop({
                                type: 'error',
                                title: 'Withdraw',
                                body: "Request canceled",
                                timeout: 3000
                            });

              })
              .error(function(data, status, headers, config) {
                  alert(data);
              });
      }

      $scope.withdraw_payout = function(item){
        $http.post($location.absUrl() + "/req/withdrawAccept", {
            'acceptWithdraw': JSON.stringify(item)
        })
            .success(function(data, status, headers, config) {
              $scope.getData();
              toaster.pop({
                              type: 'success',
                              title: 'Withdraw',
                              body: item.firstname + " "+ item.lastname+ "'s request accepted",
                              timeout: 3000
                          });

            })
            .error(function(data, status, headers, config) {
                alert(data);
            });
      }

      $scope.withdraw_pending = function(item){
        $http.post($location.absUrl() + "/req/withdrawPending", {
            'pendingWithdraw': JSON.stringify(item)
        })
            .success(function(data, status, headers, config) {
              $scope.getData();
              toaster.pop({
                              type: 'info',
                              title: 'Pending',
                              body: item.firstname + " "+ item.lastname+ "'s request pending",
                              timeout: 3000
                          });

            })
            .error(function(data, status, headers, config) {
                alert(data);
            });
      }

      $scope.withdraw_declined = function(item){
        $http.post($location.absUrl() + "/req/withdrawDecline", {
            'declineWithdraw': JSON.stringify(item)
        })
            .success(function(data, status, headers, config) {
              $scope.getData();
              toaster.pop({
                              type: 'error',
                              title: 'Declined',
                              body: item.firstname + " "+ item.lastname+ "'s request declined",
                              timeout: 3000
                          });

            })
            .error(function(data, status, headers, config) {
                alert(data);
            });
      }

      $scope.withdraw_delete = function(item) {
          $http.post($location.absUrl() + "/req/withdrawCancel", {
              'cancelWithdraw': JSON.stringify(item)
          })
              .success(function(data, status, headers, config) {
                $scope.getData();
                toaster.pop({
                                type: 'error',
                                title: 'Withdraw',
                                body: item.firstname + " "+ item.lastname + "'s request deleted",
                                timeout: 3000
                            });

              })
              .error(function(data, status, headers, config) {
                  alert(data);
              });
      }

      $scope.saveSettings = function(){

            $http.post($location.absUrl() + "/req/saveSettings", {
                'saveSettings': JSON.stringify($scope.settings)
            })
            .success(function(data, status, headers, config) {

              toaster.pop({
                              type: 'Info',
                              title: 'Settings Saved',
                              body: "Your changes got saved.",
                              timeout: 3000
                          });
              $scope.getData();
            })
            .error(function(data, status, headers, config) {
                alert(data);
            });

      }

      $scope.saveUserSettings = function(){

            $http.post($location.absUrl() + "/req/saveUserSettings", {
                'saveUserSettings': JSON.stringify($scope.user_settings)
            })
            .success(function(data, status, headers, config) {

              toaster.pop({
                              type: 'Info',
                              title: 'Settings Saved',
                              body: "Your changes got saved.",
                              timeout: 3000
                          });

            })
            .error(function(data, status, headers, config) {
                alert(data);
            });

      }

      $scope.getInstagramPicture = function(){

        toaster.pop({
                        type: 'info',
                        title: 'Searching Profil Picture.',
                        body: 'Searching '+$scope.user_settings.username + "'s Picture.",
                        timeout: 3000
                    });

        $http.post($location.absUrl() + "/req/getInstagramPicture", {
            'instagramName': $scope.user_settings.username
        })
        .success(function(data, status, headers, config) {

          if(data.result){

           $scope.user_settings.picture_link = data.picture;


           toaster.pop({
                           type: 'success',
                           title: 'Picture found.',
                           body: $scope.user_settings.username + "'s Picture found.",
                           timeout: 3000
                       });

          }else{

            toaster.pop({
                            type: 'error',
                            title: 'Search Error',
                            body: "No Profilpicture found.",
                            timeout: 3000
                        });

          }

        })
        .error(function(data, status, headers, config) {
            alert(data);
        });

      }

      $scope.setLink = function(item){

        $scope.editLink = item;
        $scope.editState = true;

        if($scope.editLink.status == 1){
          $scope.editLink.status = "1";
        }else{
          $scope.editLink.status = "0";
        }

      }

      $scope.deleteLink = function(item){
        $scope.user_links.splice($scope.user_links.indexOf(item), 1);
        $scope.user_settings.links = JSON.stringify($scope.user_links);
        toaster.pop({
                        type: 'success',
                        title: 'Success',
                        body: "Link Deleted.",
                        timeout: 3000
                    });
        $scope.saveUserSettings();
      }

      $scope.saveLink = function(){
        var error = {};
            error.state = true;
            error.title = "Input error"
            error.msg = "";

        if(typeof $scope.editLink.name == "undefined"){$scope.editLink.name = "";}
        if(typeof $scope.editLink.link == "undefined"){$scope.editLink.link = "";}
        if(typeof $scope.editLink.position == "undefined"){$scope.editLink.position = 9999;}


        //check the name Input
        var expressionUrl = /\`|\^|\[|\{|\]|\}|\||\\|\'|\<|\>|\/|\""|\;/gi;
        var regexName = new RegExp(expressionUrl);
        //check link input
        var expressionName = /[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi;
        var regexUrl = new RegExp(expressionName);
        // check order Input
        var expressionOrder = /^[0-9]+$/gi;
        var regexOrder = new RegExp(expressionOrder);

        var pattern = /^((http|https|ftp):\/\/)/;

        if(!pattern.test($scope.editLink.link)) {
            $scope.editLink.link = "https://" + $scope.editLink.link;
        }

        if (!$scope.editLink.name.match(regexName)) {
          if ($scope.editLink.link.match(regexUrl)) {
            if (String($scope.editLink.position).match(regexOrder)) {
                error.state = false;
                if($scope.editState){

                  $scope.user_settings.links = JSON.stringify($scope.user_links);
                  $scope.saveUserSettings();
                  $scope.editLink = {};
                  $scope.editState = false;

                }else{

                  if(parseInt($scope.settings.biolinkcount) > $scope.user_links.length){

                  $scope.user_links.push($scope.editLink);
                  $scope.user_settings.links = JSON.stringify($scope.user_links);
                  $scope.saveUserSettings();
                  $scope.editLink = {};

                  }else{
                    error.state = true;
                    error.msg = "Max allowed link count of " + $scope.settings.biolinkcount + " reached.";
                  }

                }

            } else {
              error.msg = "Position number is wrong.";
            }
          } else {
            error.msg = "Url Link hast wrong format.";
          }
        } else {
          error.msg = "Link Name have wrong Charachters, try a-Z0-9.";
        }

        if(error.state){

          toaster.pop({
                          type: 'error',
                          title: error.title,
                          body: error.msg,
                          timeout: 3000
                      });

        }

      }

      $scope.copyClipboard = function(){

        var copyTextarea = document.querySelector('[name="refurl"]');
        copyTextarea.removeAttribute("disabled");
        copyTextarea.select();
        var successful = document.execCommand('copy');
        copyTextarea.setAttribute("disabled", true);

      }

      var loop;
      $scope.refresh = function() {
        if ( angular.isDefined(loop) ) return;
        loop = $interval(function() {

    		if($scope.menu == "affiliate" || $scope.menu == "dashboard"){
              $scope.getData();
    		}

        }, 5000);
      };

      $scope.refresh();


    });

})();
