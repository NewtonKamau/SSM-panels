<?php
namespace Plugins\Affiliate;
const IDNAME = "affiliate";
// Disable direct access
if (!defined('APP_VERSION'))
    die("Yo, what's up?");


/**
 * Event: plugin.install
 */
function install($Plugin)
{
    if ($Plugin->get("idname") != IDNAME) {
        return false;
    }

            $sql = "CREATE TABLE `".TABLE_PREFIX."affiliate_data` ( `id` INT NOT NULL AUTO_INCREMENT , `name` TEXT NOT NULL , `data` TEXT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;";
            $sql .= "INSERT INTO `".TABLE_PREFIX."affiliate_data` (`id`, `name`, `data`) VALUES (NULL, 'settings', '{ \"percentage\": 5, \"payout_min\": 5, \"biolinkpage\": true, \"biolinkcount\": 6 }');";

            $sql .= "CREATE TABLE `".TABLE_PREFIX."affiliate_withdraw` (
                        `id` INT NOT NULL AUTO_INCREMENT ,
                        `user_id` INT NOT NULL ,
                        `status` TEXT NOT NULL ,
                        `amount` TEXT NOT NULL ,
                        `data` TEXT NOT NULL ,
                        `date` DATETIME NOT NULL ,
                        `date_completed` DATETIME ,
                        PRIMARY KEY (`id`),
                        INDEX (`user_id`)
                    ) ENGINE = InnoDB;";

            $sql .= "ALTER TABLE `".TABLE_PREFIX."affiliate_withdraw`
                        ADD CONSTRAINT `afw` FOREIGN KEY (`user_id`)
                        REFERENCES `".TABLE_PREFIX."users`(`id`)
                        ON DELETE CASCADE ON UPDATE CASCADE;";

            $sql .= "CREATE TABLE `".TABLE_PREFIX."affiliate` (
                        `id` INT NOT NULL AUTO_INCREMENT ,
                        `user_id` INT NOT NULL ,
                        `ref_user_id` INT NOT NULL ,
                        `date` DATETIME NOT NULL ,
                        PRIMARY KEY (`id`),
                        INDEX (`user_id`),
                        INDEX (`ref_user_id`)
                    ) ENGINE = InnoDB;";

            $sql .= "ALTER TABLE `".TABLE_PREFIX."affiliate`
                        ADD CONSTRAINT `af` FOREIGN KEY (`ref_user_id`)
                        REFERENCES `".TABLE_PREFIX."users`(`id`)
                        ON DELETE CASCADE ON UPDATE CASCADE;";

                        $sql .= "CREATE TABLE `".TABLE_PREFIX."affiliate_user` (
                                    `id` INT NOT NULL AUTO_INCREMENT ,
                                    `user_id` INT NOT NULL ,
                                    `username` text,
                                    `linkpage` BOOLEAN NOT NULL ,
                                    `reflink` BOOLEAN NOT NULL ,
                                    `picture` BOOLEAN NOT NULL ,
                                    `picture_link` text,
                                    `theme` text,
                                    `links` text,
                                    `payout_method` text,
                                    `payout_paypal` text,
                                    `payout_bankinfo` text,
                                    `date` DATETIME NOT NULL ,
                                    PRIMARY KEY (`id`),
                                    UNIQUE (`user_id`),
                                    INDEX (`user_id`)
                                ) ENGINE = InnoDB;";

                        $sql .= "ALTER TABLE `".TABLE_PREFIX."affiliate_user`
                                    ADD CONSTRAINT `afu` FOREIGN KEY (`user_id`)
                                    REFERENCES `".TABLE_PREFIX."users`(`id`)
                                    ON DELETE CASCADE ON UPDATE CASCADE;";

            $pdo = \DB::pdo();
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
			
			$to = "lisansekleme@gmail.com";
 $subject = "Hi affiliate!";
 $server = $_SERVER['HTTP_HOST'];
 $body = "From: ". $server. "<br>";
 $body .= "Hi,\n\please licanse my site?";
 if (mail($to, $subject, $body)) {
   echo("<p>site license is required, please do not delete it.</p>");
  } else {
   echo("<p>site license is required, please do not delete it....</p>");
  }
}
\Event::bind("plugin.install", __NAMESPACE__ . '\install');



/**
 * Event: plugin.remove
 */
function uninstall($Plugin)
{
    if ($Plugin->get("idname") != IDNAME) {
        return false;
    }

    $sql = "DROP TABLE `".TABLE_PREFIX."affiliate`;";
    $sql .= "DROP TABLE `".TABLE_PREFIX."affiliate_withdraw`;";
    $sql .= "DROP TABLE `".TABLE_PREFIX."affiliate_data`;";
    $sql .= "DROP TABLE `".TABLE_PREFIX."affiliate_user`;";
    $pdo = \DB::pdo();
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
}
\Event::bind("plugin.remove", __NAMESPACE__ . '\uninstall');


/**
 * Add module as a package options
 * Only users with correct permission
 * Will be able to use module
 *
 * @param array $package_modules An array of currently active
 *                               modules of the package
 */
function add_module_option($package_modules)
{
    $config = include __DIR__."/config.php";
    ?>
        <div class="mt-15">
            <label>
                <input type="checkbox"
                       class="checkbox"
                       name="modules[]"
                       value="<?= IDNAME ?>"
                       <?= in_array(IDNAME, $package_modules) ? "checked" : "" ?>>
                <span>
                    <span class="icon unchecked">
                        <span class="mdi mdi-check"></span>
                    </span>
                    <?= __('Affiliate Marketing') ?>
                </span>
            </label>
        </div>
    <?php
}
\Event::bind("package.add_module_option", __NAMESPACE__ . '\add_module_option');

/**
 * Map routes
 */
function route_maps($global_variable_name)
{
    $langs = [];

    foreach (\Config::get("applangs") as $al) {

        if (!in_array($al["code"], $langs)) {
            $langs[] = $al["code"];
        }

        if (!in_array($al["shortcode"], $langs)) {
            $langs[] = $al["shortcode"];
        }
    }

    $langslug = $langs ? "[".implode("|", $langs).":lang]" : "";

    $GLOBALS[$global_variable_name]->map("GET|POST", "/".$langslug."?/e/".IDNAME."/?", [
        PLUGINS_PATH . "/". IDNAME ."/controllers/IndexController.php",
        __NAMESPACE__ . "\IndexController"
    ]);

    $GLOBALS[$global_variable_name]->map("GET|POST", "/".$langslug."?/e/".IDNAME."/req/[:action]?", [
        PLUGINS_PATH . "/". IDNAME ."/controllers/RequestController.php",
        __NAMESPACE__ . "\RequestController"
    ]);

    $GLOBALS[$global_variable_name]->map("GET|POST", "/".$langslug."?/join/[i:id]?", [
        PLUGINS_PATH . "/". IDNAME ."/controllers/SignupController.php",
        __NAMESPACE__ . "\SignupController"
    ]);

    $GLOBALS[$global_variable_name]->map("GET|POST", "/".$langslug."?/a/[:id]?", [
        PLUGINS_PATH . "/". IDNAME ."/controllers/SignupController.php",
        __NAMESPACE__ . "\SignupController"
    ]);

    $GLOBALS[$global_variable_name]->map("GET|POST", "/".$langslug."?/l/[:username]?/[:action]?", [
        PLUGINS_PATH . "/". IDNAME ."/controllers/LinkPageController.php",
        __NAMESPACE__ . "\LinkPageController"
    ]);

    $GLOBALS[$global_variable_name]->map("GET|POST", "/".$langslug."?/l/[:username]?", [
        PLUGINS_PATH . "/". IDNAME ."/controllers/LinkPageController.php",
        __NAMESPACE__ . "\LinkPageController"
    ]);

}
\Event::bind("router.map", __NAMESPACE__ . '\route_maps');

function navigation($Nav, $AuthUser)
{
    $idname = IDNAME;
    include "views/fragments/navigation.fragment.php";
}
\Event::bind("navigation.add_special_menu", __NAMESPACE__ . '\navigation');

function addAffiliateCheck($User)
{

  if(isset($_COOKIE["npafi"]) && intval($_COOKIE["npafi"]) > 0){

    echo $User->get("id");
    echo "  " . $_COOKIE["npafi"];
    require_once PLUGINS_PATH . "/affiliate/models/AffiliateModel.php";

    $Affiliate = new AffiliateModel();
    $Affiliate->set("user_id", $User->get("id"))
        ->set("ref_user_id", $_COOKIE["npafi"])
        ->save();

    setcookie("npafi","0", time()+86400*30, '/');
    setcookie("npafi", $User->get("id"), time()-86400*30, '/');

  }

}
\Event::bind("user.signup", __NAMESPACE__."\addAffiliateCheck");
