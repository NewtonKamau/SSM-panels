<?php if (!defined('APP_VERSION')) die("Yo, what's up?"); ?>
<?php
    return [
        "idname" => "affiliate",
        "plugin_name" => "Affiliate Marketing",
        "plugin_uri" => "https://codingmatters.de",
        "author" => "Can Sesli",
        "author_uri" => "https://codingmatters.de",
        "version" => "4.1",
        "desc" => "Affiliate Marketing Module gives your Customers the option to recruit new clients and get a percentage of profit.",
        "icon_style" => "background-color: #A077FF; background: linear-gradient(136.03deg, #190707 0%, #4B088A 100%); color: #fff; font-size: 22px;width:auto;padding:6px 4px 5px 4px;"
    ];
