<?php if (!defined('APP_VERSION')) die("Yo, what's up?"); ?>

<div class="row clearfix" ng-if="menu == 'dashboard'">
   <div class="col s12 m6 mt-20">
      <div class="col s12 m12">
         <section class="section">
            <div class="section-content">
               <div class="clearfix numbers">
                  <div class="statistics-numeric col s12 m12">
                     <h2 class="page-secondary-title"><?= __("Customers") ?>
                       <span class="pull-right">
                         <span class="sli sli-people icon"></span>
                       </span>
                     </h2>
                  </div>
               </div>
               <div class="clearfix mt-20 box_table">
                  <div class="box_table_row">
                     <div class="statistics-numeric col s6 m3 8">
                        <span class="number">{{!customerinfo.user_count  ? '0' : customerinfo.user_count}}</span>
                        <span class="label"><?= __("Total") ?></span>
                     </div>
                     <div class="statistics-numeric col s6 m3 8 s-last">
                        <span class="number">{{!customerinfo.user_activ ? '0' : customerinfo.user_activ}}/{{!customerinfo.user_inactiv ? '0' : customerinfo.user_inactiv}}</span>
                        <span class="label"><?= __("Active/Inactive") ?></span>
                     </div>
                     <div class="statistics-numeric col s6 m3 8">
                        <span class="number">{{!customerinfo.account_count ? '0' : customerinfo.account_count}}</span>
                        <span class="label"><?= __("Accounts") ?></span>
                     </div>
                     <div class="statistics-numeric col s6 m3 8 s-last">
                        <span class="number">{{!customerinfo.user_trial ? '0' : customerinfo.user_trial}}</span>
                        <span class="label"><?= __("Trials") ?></span>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>

      <div class="col s12 m12 mt-10">
         <section class="section">
            <div class="section-content">
               <div class="clearfix numbers">
                  <div class="statistics-numeric col s12 m12">
                     <h2 class="page-secondary-title"><?= __("Affiliate") ?>
                       <span class="pull-right">
                         <span class="sli sli-graph icon"></span>
                       </span>
                     </h2>
                  </div>
               </div>
               <div class="clearfix mt-20 box_table">
                  <div class="box_table_row">
                     <div class="statistics-numeric col s6 m4">
                        <span class="number">{{!affiliateinfo.users ? '0' : affiliateinfo.users}}</span>
                        <span class="label"><?= __("Total") ?></span>
                     </div>
                     <div class="statistics-numeric col s6 m4">
                        <span class="number">{{!affiliateinfo.refs ? '0' : affiliateinfo.refs}}</span>
                        <span class="label"><?= __("Refs") ?></span>
                     </div>
                     <div class="statistics-numeric col s6 m4">
                        <span class="number">{{!affiliateinfo.commissions ? '0' : affiliateinfo.commissions}}</span>
                        <span class="label"><?= __("Commissions") ?></span>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>

      <div class="col s12 m12 mt-10">
         <section class="section">
            <div class="section-content">
               <div class="clearfix numbers">
                  <div class="statistics-numeric col s12 m12">
                     <h2 class="page-secondary-title"><?= __("Payments") ?>
                       <span class="pull-right">
                         <span class="sli sli-credit-card icon"></span>
                       </span>
                     </h2>
                  </div>
               </div>
               <div class="clearfix mt-20 box_table">
                  <div class="box_table_row">
                     <div class="statistics-numeric col s6 m4">
                        <span class="number">{{!paymentstotal ? '0 ' + currency : paymentstotal + ' '  + currency}}</span>
                        <span class="label"><?= __("Total") ?></span>
                     </div>
                     <div class="statistics-numeric col s6 m4">
                        <span class="number">{{!affiliateinfo.earned ? '0 ' + currency : affiliateinfo.earned + ' '  + currency}}</span>
                        <span class="label"><?= __("Affiliate") ?></span>
                     </div>
                     <div class="statistics-numeric col s6 m4">
                        <span class="number">{{!affiliateinfo.payouts ? '0 ' + currency : affiliateinfo.payouts + ' '  + currency}}</span>
                        <span class="label"><?= __("Payouts") ?></span>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>

   </div>

   <div class="col s12 m6 mt-20 m-last">
      <div class="col s12 m12">
        <section class="section">
          <div class="types small_tabs clearfix" style="margin-bottom:0px;">
             <label>
                <input name="dashtable" type="radio" value="withdraw" ng-model="dashboard_table">
                <div>
                   <span class="sli sli-shuffle icon"></span>
                   <div class="type">
                      <div class="name">
                         <span><?= __("Withdraw") ?></span>
                      </div>
                   </div>
                </div>
             </label>
             <label>
                <input name="dashtable" type="radio" value="affiliate" ng-model="dashboard_table">
                <div>
                   <span class="sli sli-chart icon"></span>
                   <div class="type">
                      <div class="name">
                         <span><?= __("Affiliate") ?></span>
                      </div>
                   </div>
                </div>
             </label>
             <label>
                <input name="dashtable" type="radio" value="payments" ng-model="dashboard_table">
                <div>
                   <span class="sli sli-credit-card icon"></span>
                   <div class="type">
                      <div class="name">
                         <span><?= __("Payments") ?></span>
                      </div>
                   </div>
                </div>
             </label>
          </div>

          <div ng-show="dashboard_table == 'withdraw'">
            <div class="section-header clearfix no-padding">
              <div class="clearfix numbers">
                <div class="statistics-numeric col s12 m12 l12">
                   <input class="input rightpad" name="search" type="text" placeholder="Search" ng-model="search.withdraw">
                </div>
              </div>
            </div>
             <div class="withdrawtable">
                <table class="mb-0">
                   <tbody>
                      <tr class="js-list-item" ng-repeat="whitdw in pagedWithdraw | orderBy: 'date':true | filter:search.withdraw" >

                         <td>
                           <div class="col s12 m3">
                            <div class="table-big-text block">
                               <span class="mr-5">
                                 <span class="sli sli-user icon"></span> {{whitdw.firstname}} {{whitdw.lastname}}
                               </span>
                            </div>
                            <span class="mr-5">
                              <span class="sli sli-envelope icon"></span> {{whitdw.email}}
                            </span>
                          </div>

                           <div class="col s12 m9 m-last">
                            <div class="col s12 m12">
                              <span class="tag pull-left"><span class="icon mdi mdi-information"></span> {{whitdw.payout_method == 'paypal' ? '<?= __("Paypal payout") ?>' : '<?= __("Bankaccount Payout") ?>'}}</span>
                              <span class="tag pull-right no-padding">{{whitdw.date}} <span class="icon mdi mdi-calendar"></span></span>
                            </div>
                            <div class="col s12 m12">
                              <span class="tag"><span class="icon mdi {{whitdw.payout_method == 'paypal' ? 'mdi-account-card-details' : 'mdi-bank'}}"></span> {{whitdw.payout_method == 'paypal' ? whitdw.payout_paypal : whitdw.payout_bankaccount}}</span>
                              <span class="pull-right">
                                <span class="tag c-yellow" ng-if="whitdw.status == 'pending'"><span class="icon mdi mdi-alert-circle"></span> <?= __("Pending") ?></span>
                                <span class="tag c-green" ng-if="whitdw.status == 'paid'"><span class="icon mdi mdi-check-circle"></span> <?= __("Paid") ?></span>
                                <span class="tag c-red" ng-if="whitdw.status == 'declined'"><span class="icon mdi mdi-close-circle"></span> <?= __("Declined") ?></span>
                                <span class="tag pr-0 c-black">{{whitdw.amount}} {{currency}}</span>
                              </span>
                            </div>
                           </div>

                         </td>

                         <td>
                           <button type="button" class="small button lbutton button--simple c-green" ng-click="withdraw_payout(whitdw)" ng-if="whitdw.status != 'paid'"><span class="icon mdi mdi-check"></span></button>
                           <button type="button" class="small button lbutton button--simple c-yellow" ng-click="withdraw_pending(whitdw)" ng-if="whitdw.status != 'pending'"><span class="icon mdi mdi-account-search"></span></button>
                           <button type="button" class="small button lbutton button--simple c-red" ng-click="withdraw_declined(whitdw)" ng-if="whitdw.status != 'declined'"><span class="icon mdi mdi-close"></span></button>
                           <button type="button" class="small button lbutton button--simple c-red" ng-click="withdraw_delete(whitdw)" ng-if="whitdw.status == 'declined'"><span class="icon mdi mdi-delete"></span></button>
                         </td>

                      </tr>
                   </tbody>
                </table>
             </div>
         </div>

         <div ng-show="dashboard_table == 'affiliate'">
           <div class="section-header clearfix no-padding">
             <div class="clearfix">
               <div class="col s12 m12 l12">
                  <input class="input rightpad" name="search" type="text" placeholder="Search" ng-model="search.affiliates">
               </div>
             </div>
           </div>
            <div class="fixedtable">
               <table class="mb-0">
                  <tbody>
                    <tr ng-repeat="affuser in pagedAffiliates | orderBy: 'date':true | filter:search.affiliates">
                       <td>
                          <div class="table-big-text mb-5">
                             <span class="mr-5">
                             <span class="sli sli-user icon"></span> {{affuser.firstname}} {{affuser.lastname}}
                             </span>
                          </div>

                          <span>{{affuser.date | dateFormat}} <span class="sli sli-calendar icon"></span></span>
                          <span>{{affuser.commissions}} <span class="sli sli-layers icon"></span></span>
                          <span>{{affuser.spend == 0 ? '0 ' + currency : '+' + affuser.spend + ' ' + currency}}</span>
                      </td>
                    </tr>
                  </tbody>
               </table>
            </div>
        </div>

        <div ng-show="dashboard_table == 'payments'">
          <div class="section-header clearfix no-padding">
            <div class="clearfix">
              <div class="col s12 m12 l12">
                 <input class="input rightpad" name="search" type="text" placeholder="<?= __("Search") ?>" ng-model="search.payments">
              </div>
            </div>
          </div>
           <div class="fixedtable">
              <table class="mb-0">

                 <tbody>
                   <tr ng-repeat="payment in pagedPayments | orderBy: 'date':true | filter:search.payments">
                      <td>

                         <div class="table-big-text mb-5">
                            <span class="mr-5">
                            <span class="sli {{payment.icon}} icon"></span> {{payment.firstname}} {{payment.lastname}}
                            </span>
                         </div>

                         <span>{{payment.date | dateFormat}} <span class="sli sli-calendar icon"></span></span>
                         <span>{{payment.package}} <span class="sli sli-layers icon"></span></span>
                         <span>{{payment.paid == 0 ? '0 ' + currency : '+' + payment.paid + ' ' + currency}}</span>
                      </td>
                   </tr>
                 </tbody>
              </table>
           </div>
       </div>

        </section>
      </div>
   </div>
 </div>

  <div class="clearfix" ng-if="menu == 'settings'">

          <aside class="skeleton-aside-settings">
            <div class="asidenav">
                <div class="asidenav-group">
                    <div class="asidenav-title"><?= __("General Settings") ?></div>
                    <ul>
                       <li class="{{menusettings.menu == 'withdraw' ? 'active' : ''}}" ng-click="menusettings.menu = 'withdraw'"><a href="javascript:void(0)"><?= __("Withdraw") ?></a></li>
                       <li class="{{menusettings.menu == 'biolinkpage' ? 'active' : ''}}" ng-click="menusettings.menu = 'biolinkpage'"><a href="javascript:void(0)"><?= __("Biolinkpage") ?></a></li>
                    </ul>
                </div>
            </div>
          </aside>

           <section class="skeleton-content-settings">

             <div class="section-content" style="padding:15px;" ng-if="menusettings.menu == 'withdraw'">
                <form>
                   <div class="section-header clearfix">
                      <h2 class="section-title"><?= __("Withdraw Settings") ?></h2>
                   </div>
                   <div class="section-content">
                      <div class="clearfix">
                         <div class="col s12 m6 l5">
                            <div class="mb-40">
                               <label class="form-label"><?= __("Payout percentage") ?></label>
                               <input class="input js-required" name="geonames-username" type="number" ng-model="settings.percentage" placeholder="5">
                               <ul class="field-tips">
                                  <li><?= __("Payout percentage, default is 5%") ?></li>
                               </ul>
                            </div>
                            <div class="mb-40">
                               <label class="form-label"><?= __("Withdraw min amount") ?></label>
                               <input class="input js-required" name="geonames-username" type="number" ng-model="settings.payout_min" placeholder="3">
                               <ul class="field-tips">
                                  <li><?= __("Minimal amount for withdraw requests, default is 5") ?> {{currency}}</li>
                               </ul>
                            </div>
                            <button class="fluid button" ng-click="saveSettings()"><?= __("Save") ?></button>
                         </div>
                      </div>
                   </div>
                </form>
             </div>

             <div class="section-content" style="padding:15px;" ng-if="menusettings.menu == 'biolinkpage'">
                <form>
                   <div class="section-header clearfix">
                      <h2 class="section-title"><?= __("Biolink page Settings") ?></h2>
                   </div>
                   <div class="section-content">
                      <div class="clearfix">
                         <div class="col s12 m6 l5">
                            <div class="mb-20">
                               <label>
                                  <input type="checkbox" class="checkbox" name="new-user" ng-model="settings.biolinkpage">
                                  <span>
                                     <span class="icon unchecked">
                                     <span class="mdi mdi-check"></span>
                                     </span>
                                     <?= __("Biolink Page") ?>
                                     <ul class="field-tips">
                                        <li><?= __("Enable or disable BioLinkpage for your Customers.") ?></li>
                                     </ul>
                                  </span>
                               </label>
                            </div>
                            <div class="mb-40">
                               <label class="form-label"><?= __("Biolink Count") ?></label>
                               <input class="input js-required" type="text" ng-model="settings.biolinkcount">
                               <ul class="field-tips">
                                  <li><?= __("Maximal allowed Biolink Count, default is 5") ?></li>
                               </ul>
                            </div>

                            <button class="fluid button" ng-click="saveSettings()"> <?= __("Save") ?></button>

                         </div>
                      </div>
                   </div>
                </form>
             </div>

           </section>

  </div>
