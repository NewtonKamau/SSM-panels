<?php if (!defined('APP_VERSION')) die("Yo, what's up?"); ?>

<div class="row clearfix" ng-if="menu == 'dashboard'">
   <div class="clearfix">
      <div class="col s12 m6 l6 mt-30">
         <section class="section">
            <div class="section-content account-summary">
               <div class="clearfix numbers">
                  <div class="statistics-numeric col s12 m6 l6">
                     <h2 class="page-secondary-title">Affiliate Summary</h2>
                  </div>
                  <div class="statistics-numeric col s12 m6 l6" style="text-align:right;">
                     <h2 class="page-secondary-title"><span class="sli sli-pie-chart icon"></span></h2>
                  </div>
               </div>
               <div class="clearfix mt-20 numbers">
                  <div class="statistics-numeric col s12 m4 l6">
                     <span class="number">{{totalRefs}}</span>
                     <span class="label">Total referrals</span>
                  </div>
                  <div class="statistics-numeric col s12 m4 l6">
                     <span class="number">{{totalCommissions}}</span>
                     <span class="label">Total commissions</span>
                  </div>
                  <div class="statistics-numeric col s12 m4 l6">
                     <span class="number">{{totalCommissions}}</span>
                     <span class="label">Total commissions</span>
                  </div>
               </div>
            </div>
         </section>
      </div>
      <div class="col s12 m6 m-last l6 l-last mt-30">
         <section class="section">
            <div class="section-content">
               <div class="clearfix numbers">
                  <div class="statistics-numeric col s12 m6 l6">
                     <h2 class="page-secondary-title">Account Balance</h2>
                  </div>
                  <div class="statistics-numeric col s12 m6 l6" style="text-align:right;">
                     <h2 class="page-secondary-title"><span class="sli sli-wallet icon"></span></h2>
                  </div>
               </div>
               <div class="clearfix mt-20" style="display:table;width:100%;position: relative;">
                  <div style="display: table-row;width: auto;clear: both;position: relative;">
                     <div class="statistics-numeric">
                        <span class="number">{{balance.total_spent}} $</span>
                        <span class="label">Balance</span>
                     </div>
                     <div class="statistics-numeric" style="position:absolute;bottom:0px;right:0px;">
                        <button type="button" class="small button button--light-outline" ng-click="withdraw()" ng-if="lw.status != 'pending'">Withdraw</button>
                        <button type="button" class="small button button--danger" ng-click="withdrawCancel()" ng-if="lw.status == 'pending'">Cancel Withdraw</button>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>
   </div>
 </div>
