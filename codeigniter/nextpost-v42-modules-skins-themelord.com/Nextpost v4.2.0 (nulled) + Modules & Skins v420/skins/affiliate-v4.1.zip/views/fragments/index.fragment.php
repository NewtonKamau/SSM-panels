<?php if (!defined('APP_VERSION')) die("Yo, what's up?"); ?>



<div id="post" class="skeleton skeleton--full" ng-controller="UserController" ng-init="getData()">
  <?php if($AccountType == "admin"){?>
   <div class="types clearfix mainusertabs mb-0" ng-init="menu = 'dashboard'">
      <label>
         <input name="type" type="radio" value="dashboard" ng-model="menu">
         <div>
            <span class="sli sli-grid icon"></span>
            <div class="type">
               <div class="name">
                  <span><?= __("Dashboard") ?></span>
               </div>
            </div>
         </div>
      </label>
      <label>
         <input name="type" type="radio" value="biolinkpage_user" ng-model="menu">
         <div>
            <span class="sli sli-book-open icon"></span>
            <div class="type">
               <div class="name">
                  <span><?= __("BioLink page") ?></span>
               </div>
            </div>
         </div>
      </label>
      <label>
         <input name="type" type="radio" value="settings" ng-model="menu">
         <div>
            <span class="sli sli-settings icon"></span>
            <div class="type">
               <div class="name">
                  <span><?= __("Settings") ?></span>
               </div>
            </div>
         </div>
      </label>
   </div>
 <?php }else{ ?>

   <div class="types clearfix mainusertabs mb-0" ng-init="menu = 'biolinkpage_user'">
     <label>
        <input name="type" type="radio" value="biolinkpage_user" ng-model="menu">
        <div>
           <span class="sli sli-book-open icon"></span>
           <div class="type">
              <div class="name">
                 <span><?= __("BioLink page") ?></span>
              </div>
           </div>
        </div>
     </label>
      <label>
         <input name="type" type="radio" value="affiliate" ng-model="menu">
         <div>
            <span class="sli sli-graph icon"></span>
            <div class="type">
               <div class="name">
                  <span><?= __("Affiliate") ?></span>
               </div>
            </div>
         </div>
      </label>
      <label>
         <input name="type" type="radio" value="settings_user" ng-model="menu">
         <div>
            <span class="sli sli-settings icon"></span>
            <div class="type">
               <div class="name">
                  <span><?= __("Settings") ?></span>
               </div>
            </div>
         </div>
      </label>
   </div>

 <?php } ?>

   <div class="row clearfix" ng-if="menu == 'affiliate'">
      <div class="clearfix">
         <div class="col s12 m6 l6 mt-30">
            <section class="section">
               <div class="section-content account-summary">
                  <div class="clearfix">
                     <div class="full-width">
                        <h2 class="page-secondary-title pull-left"><?= __("Affiliate Summary") ?></h2>
                        <h2 class="page-secondary-title pull-right"><span class="sli sli-pie-chart icon"></span></h2>
                     </div>
                  </div>

                  <div class="clearfix mt-20 box_table">
                     <div class="affiliate-row">
                       <div class="statistics-numeric">
                         <span class="number">{{!totalRefs ? '0' : totalRefs}}</span>
                         <span class="label"><?= __("Total referrals") ?></span>
                       </div>

                       <div class="statistics-numeric">
                         <span class="number">{{!totalCommissions ? '0' : totalCommissions}}</span>
                         <span class="label"><?= __("Total commissions") ?></span>
                       </div>

                        <div class="statistics-numeric">
                           <span class="number">{{!balance.actual ? '0 ' + currency : '+' + balance.actual + ' ' + currency}}</span>
                           <span class="label"><?= __("Balance") ?></span>
                        </div>

                        <div class="statistics-numeric">
                           <span class="number">{{!balance.total ? '0 ' + currency : balance.total + ' ' + currency}}</span>
                           <span class="label"><?= __("Earned") ?></span>
                        </div>
                     </div>
                  </div>

                  <div class="clearfix mt-20 box_table">
                    <div class="affiliate-bottombar full-width">
                      <button type="button" class="small button {{lw.status != 'pending' ? 'button--light-outline' : 'button--danger'}}" ng-click="withdraw_action()">{{lw.status != 'pending' ? 'Withdraw' : 'Cancel Withdraw'}}</button>
                       <span class="label"><?= __("Minimal withdraw amount is") ?> {{!settings.payout_min ? '' : + settings.payout_min + ' ' + currency}}</span>
                    </div>
                  </div>

               </div>
            </section>
         </div>
         <div class="col s12 m6 m-last l6 l-last mt-30 text-center">
            <h1 class="mb-10 text-center"><?= __("Refer your friends") ?></h1>
            <h3 class="mt-5 ng-binding mb-10"><?= __("and get") ?> {{settings.percentage}} % <?= __("from everything they spend on") ?> <?= site_settings("site_name") ?>!</h3>
            <div class="full-line mb-15">
                <input class="input text-center col s12 m8 offset-m2" type="text" disabled value="<?= APPURL . '/a/' . $AuthUser->get("id")?>" name="refurl">
            </div>
            <div class="full-line">
              <button class="button col s12 m4 offset-m4" type="submit" ng-click="copyClipboard()"><?= __("Copy Referral link") ?></button>
            </div>
         </div>
      </div>
      <div class="clearfix">
         <div class="col s12 m6 16 mt-30">
            <section class="section">
               <div class="section-header clearfix">
                  <div class="clearfix">
                     <div class="full-width">
                        <h2 class="page-secondary-title pull-left"><?= __("Referrals") ?></h2>
                        <h2 class="page-secondary-title pull-right"><span class="sli sli-people icon"></span></h2>
                     </div>
                  </div>
               </div>

               <div class="fixedtable usertable">
                  <table class="mb-0">
                     <tbody>
                       <tr ng-repeat="refuser in pagedRefs | orderBy: 'date':true">
                          <td>
                             <div class="table-big-text mb-5">
                                <span class="mr-5">
                                <span class="sli sli-user icon"></span> {{refuser.firstname}} {{refuser.lastname}}
                                </span>
                             </div>

                             <span>{{refuser.date | dateFormat}} <span class="sli sli-calendar icon"></span></span>
                             <span>{{refuser.commissions}} <span class="sli sli-layers icon"></span></span>
                         </td>
                       </tr>
                     </tbody>
                  </table>
               </div>

            </section>
         </div>
         <div class="col s12 m6 16 mt-30 m-last l-last">
            <section class="section">
               <div class="section-header clearfix">
                  <div class="clearfix">
                     <div class="full-width">
                        <h2 class="page-secondary-title pull-left"><?= __("Affiliate Activitys") ?></h2>
                        <h2 class="page-secondary-title pull-right"><span class="sli sli-info icon"></span></h2>
                     </div>
                  </div>
               </div>
               <div class="fullhigh a-activitys">
                  <table class="plugins-table mb-0">
                     <tbody class="js-loadmore-content">
                        <tr class="js-list-item" ng-repeat="timeline in pagedTimeline | orderBy: 'date':true">
                           <td class="a-activitys-td-first">
                              <div class="table-big-text mb-5">
                                 <span class="mr-5">
                                 <span class="sli {{timeline.icon}} icon"></span> {{timeline.firstname}} {{timeline.lastname}}
                                 </span>
                              </div>
                           </td>
                           <td class="a-activitys-td">
                              <span ng-if="timeline.package">{{!timeline.paid ? '0 ' + currency : '+' + timeline.paid + ' ' + currency}}</span>
                              <span ng-if="timeline.withdraw" style="color:{{timeline.color}};">{{!timeline.amount ? '0 ' + currency : '-' + timeline.amount + ' ' + currency}}</span>
                              <span class="a-activitys-td-icon" ng-if="timeline.follow">+1 <span class="sli sli-user icon"></span></span>
                           </td>
                           <td class="a-activitys-td">
                              <span ng-if="timeline.package">{{timeline.package}} <span class="sli sli-social-dropbox icon"></span></span>
                              <span ng-if="timeline.follow"><?= __("Trial Package") ?> <span class="sli sli-social-dropbox icon"></span></span>
                           </td>
                           <td class="a-activitys-td">
                              {{timeline.date | dateFormat}} <span class="sli sli-calendar icon"></span>
                           </td>
                        </tr>
                     </tbody>
                  </table>
               </div>
            </section>
         </div>
      </div>
   </div>

   <div class="clearfix" ng-if="menu == 'settings_user'">

            <aside class="skeleton-aside-settings">
              <div class="asidenav">
                  <div class="asidenav-group">
                      <div class="asidenav-title"><?= __("Settings") ?></div>
                      <ul>
                        <li class="{{menusettings_user.menu == 'payout' ? 'active' : ''}}" ng-click="menusettings_user.menu = 'payout'"><a href="javascript:void(0)"><?= __("Payout") ?></a></li>
                      </ul>
                  </div>
              </div>
            </aside>

            <section class="skeleton-content-settings">
            <span ng-if="menusettings_user.menu == 'payout'">
              <div class="section-header clearfix">
                 <h2 class="section-title"><?= __("Payout Settings") ?></h2>
              </div>

              <div class="section-content" style="padding:15px;">

                          <div class="col s12 m6">
                             <div class="mb-40">
                               <label class="form-label"><?= __("Payout method") ?></label>
                               <select name="payout_method" class="input" ng-model="user_settings.payout_method">
                                   <option value="paypal"><?= __("Paypal") ?></option>
                                   <option value="bankaccount"><?= __("Bank Transfer") ?></option>
                               </select>
                             </div>

                             <div class="mb-40" ng-if="user_settings.payout_method == 'paypal'">
                                <label class="form-label"><?= __("PayPal Email") ?></label>
                                <input class="input js-required" type="email" ng-model="user_settings.payout_paypal" placeholder="yourpaypal@emailadress.com">
                                <ul class="field-tips">
                                   <li> <?= __("Payouts will be send to this Paypal account.") ?></li>
                                  <li style="color:red;"> <?= __("Make sure this is the right one !!") ?></li>
                                </ul>
                             </div>

                             <div class="mb-40" ng-if="user_settings.payout_method == 'bankaccount'">
                                <label class="form-label"><?= __("Bank Account Information") ?></label>
                                <textarea class="input" name="bankinformation" maxlength="255" rows="5" ng-model="user_settings.payout_bankinfo" placeholder="<?= __("Provide bankaccount and contact information.") ?>"></textarea>
                                <ul class="field-tips">
                                   <li> <?= __("Payouts will be send to this Bankaccount.") ?></li>
                                </ul>
                             </div>

                             <button class="fluid button" ng-click="saveUserSettings()"><?= __("Save") ?></button>
                          </div>

              </div>

            </span>
            </section>

   </div>

   <div class="row clearfix" ng-if="menu == 'biolinkpage_user'">

     <aside class="skeleton-aside-settings">
       <div class="asidenav">
           <div class="asidenav-group linkformobil">
               <div class="asidenav-title"><?= __("Your BioLink page") ?></div>
               <ul>
                 <li><a href="<?= APPURL . '/l/'. $AuthUser->get("id") ?>"><?= __("Random Background Id link") ?></a></li>
                 <li class="linkpage-link">
                   <input class="linkpage-link-i" type="text" disabled value="<?= APPURL . '/l/' . $AuthUser->get("id")?>">
                 </li>
                 <span ng-if="user_settings.username">
                 <li><a href="<?= APPURL . '/l/'?>{{user_settings.username}}" ><?= __("Random Background Username link") ?></a></li>
                 <li class="linkpage-link">
                   <input class="linkpage-link-i" type="text" disabled value="<?= APPURL . '/l/'?>{{user_settings.username}}">
                 </li>
                </span>
               </ul>
           </div>

           <div class="asidenav-group mt-15 biolink-list">
               <div class="asidenav-title"><?= __("Static Background Links") ?></div>
               <ul>
                 <?php foreach($Styles as $style){?>
                 <li><a href="<?= APPURL . '/l/' . $AuthUser->get("id") . '/'. $style ?>"><?= $style ?></a></li>
                 <li class="linkpage-link">
                   <input type="text" class="linkpage-link-i" disabled value="<?= APPURL . '/l/' . $AuthUser->get("id") . '/'. $style ?>">
                 </li>
                 <?php } ?>
               </ul>
           </div>
       </div>
     </aside>

     <section class="skeleton-content-settings">

       <div class="section-header clearfix">
          <h2 class="section-title"><?= __("BioLink page") ?></h2>
       </div>
       <div class="section-content" style="padding:15px;">
                <div class="clearfix">
                   <div class="col s12 m12 l12">
                      <div class="col s12 mb-20 mt-5 m4 bioc-cb">
                       <div class="mb-20">
                           <label>
                              <input type="checkbox" class="checkbox" name="linkpage" ng-model="user_settings.linkpage">
                              <span>
                                 <span class="icon unchecked">
                                 <span class="mdi mdi-check"></span>
                                 </span>
                                 <?= __("Enable Biolink Page") ?>
                              </span>
                           </label>
                       </div>
                         <label>
                            <input type="checkbox" class="checkbox" name="picture" ng-model="user_settings.picture">
                            <span>
                               <span class="icon unchecked">
                               <span class="mdi mdi-check"></span>
                               </span>
                               <?= __("Include Profile Picture") ?>
                            </span>
                         </label>
                      </div>

                      <div class="col s12 mb-10 mt-5 m8 m-last text-right biosettings">
                        <div class="full-width">
                         <img ng-src="{{user_settings.picture_link ? user_settings.picture_link : 'https://via.placeholder.com/70x70'}}" alt="{{user_settings.username}}">
                       </div>
                         <input class="input" type="text" placeholder="Instagram username" maxlength="100" ng-model="user_settings.username">
                         <button type="button" class="small button button--light-outline mb-5" ng-click="getInstagramPicture()"> <span class="mdi mdi-account-search"></span> <?= __("Search") ?></button>
                         <div class="full-width">
                           <button type="button" class="small button fullbutton" ng-click="saveUserSettings()"><?= __("Save Settings") ?></button>
                         </div>
                      </div>

                     </div>

                     <div class="col s12 m12 l12">

                          <div class="section-header clearfix ml-0 pr-0 pl-0 pt-0 pb-15">

                                <div class="col s12 linkinput">

                                  <input class="input input-linkname" type="text" placeholder="Name" maxlength="100" ng-model="editLink.name" required />
                                  <input class="input input-link" type="text" placeholder="Link" maxlength="100" ng-model="editLink.link">
                                  <input class="input input-order" name="ordernumber" type="number" placeholder="Order" ng-model="editLink.position">
                                  <select class="input-status" class="input ng-pristine ng-untouched ng-valid" ng-model="editLink.status">
                                     <option value="1"><?= __("Active") ?></option>
                                     <option value="0"><?= __("Inactive") ?></option>
                                  </select>
                                  <button type="button" class="small button button--dark input-button" ng-click="saveLink()"> <span class="mdi mdi-playlist-plus"></span> {{editState ? '<?= __("Save Changes") ?>' : '<?= __("Add link") ?>'}}</button>

                                </div>

                          </div>

                          <div class="fullhigh add-links-form">
                             <table class="mb-0">
                                <tbody>
                                   <tr class="js-list-item" ng-repeat="link in user_links | orderBy: 'position' track by $index">
                                      <td class="link-item-name">
                                         <div class="table-big-text mb-5">
                                            <span class="mr-5">
                                            <span class="mdi mdi-information"></span> {{link.name}}
                                            </span>
                                         </div>
                                      </td>
                                      <td class="link-item-link">
                                         <span><a href="{{link.link}}"><span class="mdi mdi-link-variant"></span></a> {{link.link}}</span>
                                      </td>
                                      <td class="link-item-pos">
                                         <span><span class="mdi mdi-format-list-numbers"></span> {{link.position}}</span>
                                      </td>

                                      <td class="link-item-status">
                                         <span style="color:{{link.status =='1' ? 'green' : 'red'}};" >{{link.status =='1' ? 'active' : 'inactive'}}</span>
                                      </td>

                                      <td class="link-item-button">
                                        <button type="button" class="small button lbutton" ng-click="setLink(link)" ><span class="icon mdi mdi-table-edit"></span></button>
                                        <button type="button" class="small button lbutton button--danger" ng-click="deleteLink(link)" ><span class="icon mdi mdi-delete"></span></button>
                                      </td>
                                   </tr>
                                </tbody>
                             </table>
                          </div>
                     </div>
                </div>
       </div>
     </section>

  </div>
  <?php
  if($AccountType == "admin"){
    require_once(__DIR__.'/admin.fragment.php');
  }
  ?>

</div>
