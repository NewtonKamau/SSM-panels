<?php if (!defined('APP_VERSION')) die("Yo, what's up?");  ?>
<!DOCTYPE html>
<html lang="<?= ACTIVE_LANG ?>">
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>
  <meta name="theme-color" content="#fff">

  <meta name="description" content="<?= site_settings("site_description") ?>">
  <meta name="keywords" content="<?= site_settings("site_keywords") ?>">
  <link rel="icon" href="<?= site_settings("logomark") ? site_settings("logomark") : APPURL."/assets/img/logomark.png" ?>" type="image/x-icon">
  <link rel="shortcut icon" href="<?= site_settings("logomark") ? site_settings("logomark") : APPURL."/assets/img/logomark.png" ?>" type="image/x-icon">

  <title><?php echo "@". $UserSettings->username; ?></title>

  <link href='https://fonts.googleapis.com/css?family=Karla:400' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="<?= PLUGINS_URL."/affiliate/assets/linkpage/bootstrap/css/bootstrap.min.css"?>">
    <link rel="stylesheet" type="text/css" href="<?= PLUGINS_URL."/affiliate/assets/linkpage/bootstrap/css/bootstrap-grid.min.css"?>">
    <link rel="stylesheet" type="text/css" href="<?= PLUGINS_URL."/affiliate/assets/linkpage/bootstrap/css/bootstrap-reboot.min.css"?>">
    <link rel="stylesheet" type="text/css" href="<?= PLUGINS_URL."/affiliate/assets/linkpage/css/style.css"?>">
	<link rel="stylesheet" type="text/css" href="<?= PLUGINS_URL."/affiliate/assets/linkpage/css/linkpage.css"?>">

</head>

<body>
  <section class="header5 grad-<?php echo $Style ?> mbr-full">

    <div class="container">
        <div class="row justify-content-center">
            <div class="mbr-white col-md-10">
				<div class="align-center">

				<?php if($UserSettings->picture){?>

				  <img class="user-img img-circle" src="<?php echo $UserSettings->picture_link ?>">

				<?php } ?>
        				<?php if($UserSettings->username != ""){?>
                  <h3>
                    <a class="mbr-text align-center display-5 pb-3 mbr-fonts-style user-name" href="<?php echo "https://www.instagram.com/" . $UserSettings->username ?>">
          						<?php
          								echo "@".$UserSettings->username;
          						?>
					         </a>
                 </h3>
				<?php } ?>
               </div>
                      <?php foreach($UserLinks as $link){?>
						<div class="mbr-section-btn align-center">
								<a class="btn btn-md btn-white-outline linkbutton" onclick="window.open('<?php echo $link->link ?>', '_blank');"><?php echo $link->name ?></a>
						</div>
                      <?php } ?>
            </div>
        </div>
    </div>

</section>

</body>

</html>
