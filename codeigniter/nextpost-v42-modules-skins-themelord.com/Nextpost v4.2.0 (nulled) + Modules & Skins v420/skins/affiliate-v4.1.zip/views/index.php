<?php if (!defined('APP_VERSION')) die("Yo, what's up?");  ?>
<!DOCTYPE html>
<html lang="<?= ACTIVE_LANG ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>
        <meta name="theme-color" content="#fff">

        <meta name="description" content="<?= site_settings("site_description") ?>">
        <meta name="keywords" content="<?= site_settings("site_keywords") ?>">

        <link rel="icon" href="<?= site_settings("logomark") ? site_settings("logomark") : APPURL."/assets/img/logomark.png" ?>" type="image/x-icon">
        <link rel="shortcut icon" href="<?= site_settings("logomark") ? site_settings("logomark") : APPURL."/assets/img/logomark.png" ?>" type="image/x-icon">

        <link rel="stylesheet" type="text/css" href="<?= APPURL."/assets/css/plugins.css?v=".VERSION ?>">
        <link rel="stylesheet" type="text/css" href="<?= APPURL."/assets/css/core.css?v=".VERSION ?>">
        <link rel="stylesheet" type="text/css" href="<?= PLUGINS_URL."/affiliate/assets/css/style.css"?>">
        <link href="//cdnjs.cloudflare.com/ajax/libs/angularjs-toaster/2.1.0/toaster.css" rel="stylesheet" />


        <title><?= __("Affiliate Marketing") ?></title>
    </head>

    <body ng-app="affiliateApp">
        <?php
            $Nav = new stdClass;
            $Nav->activeMenu = "affiliate";
            require_once(APPPATH.'/views/fragments/navigation.fragment.php');
        ?>

        <?php
            $TopBar = new stdClass;
            $TopBar->title = __("Affiliate Marketing");
            $TopBar->btn = true;
            require_once(APPPATH.'/views/fragments/topbar.fragment.php');
        ?>

        <?php
            require_once(__DIR__.'/fragments/index.fragment.php');

        ?>
        <toaster-container toaster-options="{'position-class': 'toast-bottom-right'}"></toaster-container>
        <script type="text/javascript" src="<?= APPURL."/assets/js/plugins.js?v=".VERSION ?>"></script>
        <?php require_once(APPPATH.'/inc/js-locale.inc.php'); ?>
        <script type="text/javascript" src="<?= APPURL."/assets/js/core.js?v=".VERSION ?>"></script>
        <script src="<?= PLUGINS_URL."/affiliate/assets/js/angular.min.js"?>"></script>
        <script src="<?= PLUGINS_URL."/affiliate/assets/js/angular-animate.min.js"?>"></script>
        <script src="<?= PLUGINS_URL."/affiliate/assets/js/toaster.js"?>"></script>
        <script src="<?= PLUGINS_URL."/affiliate/assets/js/angular-filter.min.js"?>"></script>
        <script src="<?= PLUGINS_URL."/affiliate/assets/js/app.js"?>"></script>
        <!-- GOOGLE ANALYTICS -->
        <?php require_once(APPPATH.'/views/fragments/google-analytics.fragment.php'); ?>
    </body>
</html>
