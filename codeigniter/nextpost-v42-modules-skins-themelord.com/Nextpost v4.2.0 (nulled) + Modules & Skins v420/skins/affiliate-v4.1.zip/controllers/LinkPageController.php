<?php
namespace Plugins\Affiliate;

// Disable direct access
if (!defined('APP_VERSION'))
    die("Yo, what's up?");

/**
 * Index Controller
 */
class LinkPageController extends \Controller
{


    /**
     * Process
     */
    public function process()
    {
        $userid = 0;
        $Route = $this->getVariable("Route");


        if(is_numeric($Route->params->username)){
          $userid = $Route->params->username;
        }else{
          $q4 = "SELECT * FROM ".TABLE_PREFIX."affiliate_user WHERE username ='" . $Route->params->username ."'";
          $query = \DB::query($q4);
          $user =  $query->get()[0];
          $userid = $user->user_id;
        }

        $q4 = "SELECT * FROM ".TABLE_PREFIX."affiliate_user WHERE user_id =" . $userid;
        $query = \DB::query($q4);
        $userSettings =  $query->get()[0];
        $userLinks = json_decode($userSettings->links);
        $q4 = 'SELECT * FROM '.TABLE_PREFIX.'affiliate_data WHERE id = 1';
        $query = \DB::query($q4);
        $this->settings = json_decode($query->get()[0]->data);

        if(!isset($userSettings) || !$userSettings->linkpage || count($userLinks) == 0 || !$this->settings->biolinkpage){
          header("Location: ".APPURL."/signup");
          exit;
        }

        $array = array("blue", "linktree", "light", "multi", "twitch", "river", "fresh", "earlgray", "meanfruit", "plumplate", "lovekiss", "truesunset", "grownearly", "temptingazure", "landingaircraft", "widematrix");

        if(isset($Route->params->action) && in_array(strtolower($Route->params->action), $array)){

          $key = array_search(strtolower($Route->params->action), $array);
          $style = $array[$key];

        }else{

          $style = $array[rand(0,count($array) - 1)];

        }

        if(isset($userLinks)){

          usort($userLinks, array($this, "cmp"));

        }

        $this->setVariable("Style", $style);
        $this->setVariable("UserSettings", $userSettings);
        $this->setVariable("UserLinks", $userLinks);

        $this->view(PLUGINS_PATH."/affiliate/views/linkpage.php", null);
    }

    function cmp($a, $b)
    {
        return strcmp(intval($a->position), intval($b->position));
    }

}
