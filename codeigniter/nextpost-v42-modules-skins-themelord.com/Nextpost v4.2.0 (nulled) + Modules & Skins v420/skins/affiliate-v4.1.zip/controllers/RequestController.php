<?php
namespace Plugins\Affiliate;
// Disable direct access
if (!defined('APP_VERSION'))
    die("Yo, what's up?");

require_once PLUGINS_PATH . "/affiliate/models/UserModel.php";

/**
 * Index Controller
 */
class RequestController extends \Controller
{

    public $settings = null;
    /**
     * Process
     */
    public function process()
    {

        $AuthUser = $this->getVariable("AuthUser");
        $Route = $this->getVariable("Route");

        $q4 = 'SELECT * FROM '.TABLE_PREFIX.'affiliate_data WHERE id = 1';
        $query = \DB::query($q4);

        $this->settings = json_decode($query->get()[0]->data);

        $q4 = 'SELECT * FROM '.TABLE_PREFIX.'general_data WHERE id = 1';
        $query = \DB::query($q4);

        $jsontmp = json_decode($query->get()[0]->data);

        $this->settings->currency = $jsontmp->currency;

        // Auth
        if (!$AuthUser){
          header("Location: ".APPURL."/post");
          exit;
        } else if ($AuthUser->isExpired()) {
          header("Location: ".APPURL."/post");
          exit;
        }

        $user_modules = $AuthUser->get("settings.modules");

        if (!is_array($user_modules) || !in_array("affiliate", $user_modules)) {
          header("Location: ".APPURL."/post");
          exit;
        }


        if($Route->params->action == "getRefs"){


          if($AuthUser->get("account_type") == 'admin'){
            $this->resp->isAdmin = true;

            //------------------- Customer Tab
            // User data
            $q4 = 'SELECT count(Distinct id) AS user_count, SUM(if('.TABLE_PREFIX.'users.is_active = "1", 1, 0)) AS user_activ, SUM(if('.TABLE_PREFIX.'users.is_active = "0", 1, 0)) AS user_inactiv, SUM(if('.TABLE_PREFIX.'users.package_id = "0", 1, 0)) AS user_trial FROM  '.TABLE_PREFIX.'users  WHERE account_type = "member"';
            $query = \DB::query($q4);
            $this->resp->customerinfo = $query->get()[0];
            // Account data
            $q4 = 'SELECT count(id) AS account_count FROM '.TABLE_PREFIX.'accounts';
            $query = \DB::query($q4);
            $this->resp->customerinfo->account_count = $query->get()[0]->account_count;

            //---------------
            // commissions and earned from that
            $q1 = 'SELECT sum(t1.commissions) as commissions,sum(t1.spend) as earned FROM ';
            $q1 .= '(SELECT '.TABLE_PREFIX.'affiliate.user_id,SUM(if('.TABLE_PREFIX.'orders.status = "paid", 1, 0)) AS commissions,SUM(if('.TABLE_PREFIX.'orders.status = "paid", '.TABLE_PREFIX.'orders.paid, 0)) AS spend FROM '.TABLE_PREFIX.'affiliate LEFT JOIN '.TABLE_PREFIX.'orders ON '.TABLE_PREFIX.'affiliate.user_id = '.TABLE_PREFIX.'orders.user_id GROUP BY '.TABLE_PREFIX.'affiliate.user_id) as t1 ';
            $q1 .= 'JOIN '.TABLE_PREFIX.'users ON '.TABLE_PREFIX.'users.id = t1.user_id';
            $query = \DB::query($q1);
            $this->resp->affiliate = $query->get()[0];
            // we need affiliate and spent amount
            // Account data
            $q4 = 'SELECT count(Distinct '.TABLE_PREFIX.'affiliate.ref_user_id) AS affiliate_user, count(Distinct '.TABLE_PREFIX.'affiliate.user_id) AS affiliate_refs FROM '.TABLE_PREFIX.'affiliate';
            $query = \DB::query($q4);
            $qtemp = $query->get()[0];

            $this->resp->affiliate->users = $qtemp->affiliate_user;
            $this->resp->affiliate->refs = $qtemp->affiliate_refs;

            // payout

            $q4 = 'SELECT SUM('.TABLE_PREFIX.'affiliate_withdraw.amount) AS payouts, count(id) AS payouts_count FROM '.TABLE_PREFIX.'affiliate_withdraw WHERE '.TABLE_PREFIX.'affiliate_withdraw.status ="paid" ';
            $query = \DB::query($q4);
            $qtemp = $query->get()[0];
            $this->resp->affiliate->payouts = $qtemp->payouts;
            $this->resp->affiliate->payouts_count = $qtemp->payouts_count;

            // withdraw list

            $q4 = 'SELECT '.TABLE_PREFIX.'affiliate_withdraw.*,'.TABLE_PREFIX.'users.firstname as firstname, '.TABLE_PREFIX.'users.lastname as lastname,'.TABLE_PREFIX.'users.email as email,'.TABLE_PREFIX.'affiliate_user.payout_method as payout_method,'.TABLE_PREFIX.'affiliate_user.payout_paypal as payout_paypal,'.TABLE_PREFIX.'affiliate_user.payout_bankinfo as payout_bankaccount  FROM '.TABLE_PREFIX.'affiliate_withdraw join '.TABLE_PREFIX.'users ON '.TABLE_PREFIX.'users.id = '.TABLE_PREFIX.'affiliate_withdraw.user_id join '.TABLE_PREFIX.'affiliate_user ON '.TABLE_PREFIX.'affiliate_user.user_id = '.TABLE_PREFIX.'affiliate_withdraw.user_id';
            $query = \DB::query($q4);
            $this->resp->withdraw =  $query->get();

            $q4 = 'SELECT SUM(paid) as payments_total FROM '.TABLE_PREFIX.'orders WHERE status = "paid"';
            $query = \DB::query($q4);
            $this->resp->payments_total =  $query->get()[0]->payments_total;

            // affiliate list

            $q1 = 'SELECT '.TABLE_PREFIX.'users.firstname,'.TABLE_PREFIX.'users.lastname,'.TABLE_PREFIX.'users.email,'.TABLE_PREFIX.'users.package_id,t1.user_id,t1.commissions,t1.spend,'.TABLE_PREFIX.'affiliate.date FROM ';
            $q1 .= '(SELECT '.TABLE_PREFIX.'affiliate.user_id,SUM(if('.TABLE_PREFIX.'orders.status = "paid", 1, 0)) AS commissions,SUM(if('.TABLE_PREFIX.'orders.status = "paid", '.TABLE_PREFIX.'orders.paid, 0)) AS spend FROM '.TABLE_PREFIX.'affiliate LEFT JOIN '.TABLE_PREFIX.'orders ON '.TABLE_PREFIX.'affiliate.user_id = '.TABLE_PREFIX.'orders.user_id GROUP BY '.TABLE_PREFIX.'affiliate.user_id) as t1 ';
            $q1 .= 'JOIN '.TABLE_PREFIX.'users ON '.TABLE_PREFIX.'users.id = t1.user_id JOIN '.TABLE_PREFIX.'affiliate ON '.TABLE_PREFIX.'affiliate.user_id = t1.user_id';
            $query = \DB::query($q1);
            $this->resp->affiliatelist = $query->get();

            // affiliate list

            $q1 = 'SELECT '.TABLE_PREFIX.'orders.*, '.TABLE_PREFIX.'users.firstname, '.TABLE_PREFIX.'users.lastname, '.TABLE_PREFIX.'users.email FROM '.TABLE_PREFIX.'orders JOIN '.TABLE_PREFIX.'users ON '.TABLE_PREFIX.'orders.user_id = '.TABLE_PREFIX.'users.id WHERE '.TABLE_PREFIX.'orders.status = "paid"';
            $query = \DB::query($q1);
            $this->resp->paymentlist = $query->get();

            //print_r($this->resp->withdraw);

          }else{
              $this->resp->isAdmin = false;
            // Get User Data
              $this->getRefs($AuthUser->get("id"));
              $this->getTimeline($AuthUser->get("id"));
              $this->getLastWithdrawDate($AuthUser->get("id"));
              $this->getBalance($AuthUser->get("id"));
              $this->getLastWithdraw($AuthUser->get("id"));
          }

          $q1 = 'SELECT id,IF( linkpage = 1, "true", "false") as linkpage,IF( reflink = 1, "true", "false") as reflink, IF( picture = 1, "true", "false") as picture,username,theme,picture_link,links,payout_method,payout_paypal,payout_bankinfo FROM '.TABLE_PREFIX.'affiliate_user WHERE user_id = ' . $AuthUser->get("id");
          $query = \DB::query($q1);
          $tempUserSettings = $query->get();

          if(count($tempUserSettings) > 0){
            $this->resp->user_settings = $tempUserSettings[0];
          }else{
            $UserSettings = new UserModel();
            $UserSettings->set("user_id", $AuthUser->get("id"))->save();

            $q1 = 'SELECT id,IF( linkpage = 1, "true", "false") as linkpage,IF( reflink = 1, "true", "false") as reflink, IF( picture = 1, "true", "false") as picture,username,theme,picture_link,links,payout_method,payout_paypal,payout_bankinfo FROM '.TABLE_PREFIX.'affiliate_user WHERE user_id = ' . $AuthUser->get("id");
            $query = \DB::query($q1);
            $this->resp->user_settings = $query->get()[0];
          }

          $this->resp->user_links = json_decode($this->resp->user_settings->links);

          $this->resp->settings = $this->settings;

          // Sending response.
          $this->resp->result = 1;
          $this->jsonecho();

        }else if($Route->params->action == "withdraw"){

          $this->withdraw();
          $this->resp->result = 1;
          $this->jsonecho();

        }else if($Route->params->action == "withdrawCancel"){

          $this->withdrawCancel();

        }else if($Route->params->action == "withdrawAccept"){

          $this->withdrawAccept();

        }else if($Route->params->action == "withdrawDecline"){

          $this->withdrawDecline();

        }else if($Route->params->action == "withdrawPending"){

          $this->withdrawPending();

        }else if($Route->params->action == "saveSettings"){

          $params = json_decode(file_get_contents('php://input'));

          $data = array(
              'data'        => $params->saveSettings
          );

          \DB::table(TABLE_PREFIX.'affiliate_data')->where('id', 1)->update($data);

          $this->resp->msg = "Success";
          $this->resp->result = 1;
          $this->jsonecho();

        }else if($Route->params->action == "saveUserSettings"){

          $params = json_decode(file_get_contents('php://input'));
          $saveUserSettings = json_decode($params->saveUserSettings);

          $UserSettings = new UserModel($saveUserSettings->id);
          $UserSettings->set("linkpage", $saveUserSettings->linkpage)
              ->set("reflink", $saveUserSettings->reflink)
              ->set("picture", $saveUserSettings->picture)
              ->set("username", $saveUserSettings->username)
              ->set("picture_link", $saveUserSettings->picture_link)
              ->set("links", $saveUserSettings->links)
              ->set("payout_method", $saveUserSettings->payout_method)
              ->set("payout_paypal", $saveUserSettings->payout_paypal)
              ->set("payout_bankinfo", $saveUserSettings->payout_bankinfo)
              ->save();

          $this->resp->msg = "Success";
          $this->resp->result = 1;
          $this->jsonecho();


        }else if($Route->params->action == "getInstagramPicture"){

          $this->getInstagramPicture();

        }else{

          $this->resp->msg = "Error";
          $this->resp->result = 0;
          $this->jsonecho();

        }

    }

    public function getLastWithdraw($userid){

      $q4 = 'SELECT '.TABLE_PREFIX.'affiliate_withdraw.*, '.TABLE_PREFIX.'users.firstname AS firstname,'.TABLE_PREFIX.'users.lastname AS lastname FROM '.TABLE_PREFIX.'affiliate_withdraw JOIN '.TABLE_PREFIX.'users ON '.TABLE_PREFIX.'affiliate_withdraw.user_id = '.TABLE_PREFIX.'users.id WHERE user_id =' . $userid . ' ORDER BY '.TABLE_PREFIX.'affiliate_withdraw.date DESC';
      $query = \DB::query($q4);
      $this->resp->withdraw = $query->get();

      if(count($this->resp->withdraw) > 0){
        $this->resp->lw = $this->resp->withdraw[0];
      }

    }


    public function getBalance($userid){
      // WE NEED THE EARNED VALUE ALSO AS BALANCE->earned
      $q3 = 'SELECT SUM('.TABLE_PREFIX.'orders.paid * '.($this->settings->percentage/100).') As actual FROM '.TABLE_PREFIX.'affiliate JOIN '.TABLE_PREFIX.'orders ON '.TABLE_PREFIX.'orders.user_id = '.TABLE_PREFIX.'affiliate.user_id AND '.TABLE_PREFIX.'affiliate.ref_user_id = '.$userid.' AND '.TABLE_PREFIX.'orders.status = "paid" AND '.TABLE_PREFIX.'orders.date > "'.$this->resp->last_withdraw.'"';
      $query = \DB::query($q3);

      $this->resp->balance = $query->get()[0];

      $q3 = 'SELECT SUM(amount) as total FROM '.TABLE_PREFIX.'affiliate_withdraw WHERE user_id = '.$userid.' AND status = "paid"';
      $query = \DB::query($q3);

      $this->resp->balance->total = $query->get()[0]->total;

    }

    public function getLastWithdrawDate($userid){

      $q3 = 'SELECT date,status FROM '.TABLE_PREFIX.'affiliate_withdraw WHERE user_id = '.$userid.' AND status = "paid" ORDER BY id DESC LIMIT 0, 1';
      $query = \DB::query($q3);
      $lw = $query->get();

      if(count($lw) > 0){
        $this->resp->last_withdraw = $lw[0]->date;
      }else{
        $this->resp->last_withdraw = $this->getVariable("AuthUser")->get("date");
      }

    }

    public function getTimeline($userid){

      $q2 = 'SELECT '.TABLE_PREFIX.'orders.user_id AS user_id,'.TABLE_PREFIX.'users.firstname AS firstname,'.TABLE_PREFIX.'users.lastname AS lastname,'.TABLE_PREFIX.'orders.date AS date, '.TABLE_PREFIX.'orders.payment_gateway AS gateway, ('.TABLE_PREFIX.'orders.paid * '.($this->settings->percentage/100).') AS paid, '.TABLE_PREFIX.'orders.data AS data FROM '.TABLE_PREFIX.'orders LEFT JOIN '.TABLE_PREFIX.'users ON '.TABLE_PREFIX.'orders.user_id = '.TABLE_PREFIX.'users.id WHERE user_id IN (SELECT '.TABLE_PREFIX.'affiliate.user_id FROM '.TABLE_PREFIX.'affiliate WHERE '.TABLE_PREFIX.'affiliate.ref_user_id = '.$userid.') AND '.TABLE_PREFIX.'orders.status = "paid" OR '.TABLE_PREFIX.'orders.status = "null"';
      $query = \DB::query($q2);

      $this->resp->timeline = $query->get();
    }

    public function getRefs($userid){

      $q1 = 'SELECT '.TABLE_PREFIX.'users.firstname,'.TABLE_PREFIX.'users.lastname,'.TABLE_PREFIX.'users.email,'.TABLE_PREFIX.'users.package_id,t1.user_id,t1.commissions,t1.spend,'.TABLE_PREFIX.'affiliate.date FROM ';
      $q1 .= '(SELECT '.TABLE_PREFIX.'affiliate.user_id,SUM(if('.TABLE_PREFIX.'orders.status = "paid", 1, 0)) AS commissions,SUM(if('.TABLE_PREFIX.'orders.status = "paid", '.TABLE_PREFIX.'orders.paid, 0)) AS spend FROM '.TABLE_PREFIX.'affiliate LEFT JOIN '.TABLE_PREFIX.'orders ON '.TABLE_PREFIX.'affiliate.user_id = '.TABLE_PREFIX.'orders.user_id WHERE ref_user_id = '.$userid.' GROUP BY '.TABLE_PREFIX.'affiliate.user_id) as t1 ';
      $q1 .= 'JOIN '.TABLE_PREFIX.'users ON '.TABLE_PREFIX.'users.id = t1.user_id JOIN '.TABLE_PREFIX.'affiliate ON '.TABLE_PREFIX.'affiliate.user_id = t1.user_id';
      $query = \DB::query($q1);
      $this->resp->refs = $query->get();

      if(count($this->resp->refs) == 0){
        $q1 = 'SELECT '.TABLE_PREFIX.'users.firstname,'.TABLE_PREFIX.'users.lastname,'.TABLE_PREFIX.'users.email,'.TABLE_PREFIX.'users.package_id,t1.user_id,t1.commissions,t1.spend,t1.date FROM ';
        $q1 .= '(SELECT '.TABLE_PREFIX.'affiliate.user_id,'.TABLE_PREFIX.'affiliate.date,"0" AS commissions,"0" AS spend FROM '.TABLE_PREFIX.'affiliate WHERE ref_user_id = '.$this->getVariable("AuthUser")->get("id").') as t1 ';
        $q1 .= 'JOIN '.TABLE_PREFIX.'users ON '.TABLE_PREFIX.'users.id = t1.user_id';

        $query = \DB::query($q1);
        $this->resp->refs = $query->get();
      }

    }

    public function withdraw(){

      $params = json_decode(file_get_contents('php://input'));

      if(floatval($this->settings->payout_min) > floatval($params->amount)){

        $this->resp->msg = "Min Payment amount is " .$this->settings->payout_min."$";
        $this->resp->result = 0;
        $this->jsonecho();
        die();

      }

      $q3 = 'SELECT * FROM '.TABLE_PREFIX.'affiliate JOIN '.TABLE_PREFIX.'orders ON '.TABLE_PREFIX.'orders.user_id = '.TABLE_PREFIX.'affiliate.user_id AND '.TABLE_PREFIX.'affiliate.ref_user_id = '.$this->getVariable("AuthUser")->get("id").' AND '.TABLE_PREFIX.'orders.status = "paid" AND '.TABLE_PREFIX.'orders.date > "'.$params->lastwithdraw.'"';
      $query = \DB::query($q3);

      $comissions = $query->get();

      require_once PLUGINS_PATH . "/affiliate/models/WithdrawModel.php";
      $wd = new WithdrawModel();
      $wd->set("user_id", $this->getVariable("AuthUser")->get("id"))
         ->set("status", "pending")
         ->set("amount", $params->amount)
         ->set("data", json_encode($comissions))
         ->save();

    }

    public function withdrawCancel(){

      $params = json_decode(file_get_contents('php://input'));
      $cancelwithdraw = json_decode($params->cancelWithdraw);

      require_once PLUGINS_PATH . "/affiliate/models/WithdrawModel.php";
      $wd = new WithdrawModel($cancelwithdraw->id);
      $wd->delete();

    }

    public function withdrawAccept(){

      $params = json_decode(file_get_contents('php://input'));
      $setwithdraw = json_decode($params->acceptWithdraw);

      require_once PLUGINS_PATH . "/affiliate/models/WithdrawModel.php";
      $wd = new WithdrawModel($setwithdraw->id);
      $wd->set("status", "paid")
         ->save();

    }

    public function withdrawDecline(){

      $params = json_decode(file_get_contents('php://input'));
      $setwithdraw = json_decode($params->declineWithdraw);

      require_once PLUGINS_PATH . "/affiliate/models/WithdrawModel.php";
      $wd = new WithdrawModel($setwithdraw->id);
      $wd->set("status", "declined")
         ->save();

    }

    public function withdrawPending(){

      $params = json_decode(file_get_contents('php://input'));
      $setwithdraw = json_decode($params->pendingWithdraw);

      require_once PLUGINS_PATH . "/affiliate/models/WithdrawModel.php";
      $wd = new WithdrawModel($setwithdraw->id);
      $wd->set("status", "pending")
         ->save();

    }

    public function getInstagramPicture(){

      $instagramname = "codingmatters";
      $params = json_decode(file_get_contents('php://input'));

      if(isset($params->instagramName)){$instagramname = $params->instagramName;}

      $curl = curl_init();

      $s = array(
      CURLOPT_URL => "https://www.instagram.com/" . $instagramname,
      CURLOPT_REFERER => "https://google.com",
      CURLOPT_SSL_VERIFYPEER => false,
      CURLOPT_USERAGENT => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
      CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true,
      );

      curl_setopt_array($curl, $s);
      $response = curl_exec($curl);
      curl_close($curl);

      $regex = '@<meta property="og:image" content="(.*?)"@si';
      preg_match_all($regex, $response, $return);

      $this->resp->picture = $return[1][0];
      $this->resp->result = 1;
      $this->jsonecho();

    }

}
