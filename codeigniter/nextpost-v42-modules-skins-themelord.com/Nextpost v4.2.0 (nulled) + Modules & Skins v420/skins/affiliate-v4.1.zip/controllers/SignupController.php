<?php
namespace Plugins\Affiliate;

// Disable direct access
if (!defined('APP_VERSION'))
    die("Yo, what's up?");

class SignupController extends \Controller
{

  public function process()
  {

      $AuthUser = $this->getVariable("AuthUser");
      $Route = $this->getVariable("Route");

      if ($AuthUser) {
          header("Location: ".APPURL."/post");
          exit;
      }

      if(is_numeric($Route->params->id)){
        $userid = $Route->params->id;
      }else{
        $q4 = "SELECT * FROM ".TABLE_PREFIX."affiliate_user WHERE username ='" . $Route->params->id ."'";
        $query = \DB::query($q4);
        $user =  $query->get()[0];
        $userid = $user->user_id;
      }

      setcookie("npafi", $userid, time()+86400*30, '/');

      header("Location: ".APPURL."/signup");
      exit;

  }

}
