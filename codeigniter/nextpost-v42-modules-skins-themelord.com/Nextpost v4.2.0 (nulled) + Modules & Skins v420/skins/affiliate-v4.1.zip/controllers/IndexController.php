<?php
namespace Plugins\Affiliate;

// Disable direct access
if (!defined('APP_VERSION'))
    die("Yo, what's up?");

/**
 * Index Controller
 */
class IndexController extends \Controller
{
    /**
     * Process
     */
    public function process()
    {
        $AuthUser = $this->getVariable("AuthUser");
        $styleArray = array('Fresh','River','Twitch','Multi','Light','Linktree','Blue','Earlgray','Meanfruit','Plumplate','Lovekiss','Truesunset','Grownearly','Temptingazure','Landingaircraft','Widematrix','Fresh');

        // Auth
        if (!$AuthUser){
            header("Location: ".APPURL."/login");
            exit;
        } else if ($AuthUser->isExpired()) {
            header("Location: ".APPURL."/expired");
            exit;
        }

        $user_modules = $AuthUser->get("settings.modules");
        if (!is_array($user_modules) || !in_array("affiliate", $user_modules)) {
            // Module is not accessible to this user
            header("Location: ".APPURL."/post");
            exit;
        }

        $this->setVariable("AccountType", $AuthUser->get("account_type"));
        $this->setVariable("Styles", $styleArray);
        $this->view(PLUGINS_PATH."/affiliate/views/index.php", null);
    }
}
