        <div id="welcome" class="step">
            <h1 class="page-title">Nextpost Installation</h1>
            <p>
                Welcome! Nextpost is an Instagram auto posting web application that allows you to 
                auto post, schedule and manage your Instagram accounts at the same time. 
            </p>
            <p class="fw-600 mb-40">
                Installation process is very easy and it takes less than 2 minutes!
            </p>

            <a href="javascript:void(0)" class="oval button next-btn" data-next="#agreement">Start Installation</a>
        </div>