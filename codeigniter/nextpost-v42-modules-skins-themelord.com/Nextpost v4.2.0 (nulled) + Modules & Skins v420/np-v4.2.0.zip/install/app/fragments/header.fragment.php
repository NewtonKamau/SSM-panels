        <header>
            <div class="logo-wrapper">
                <img src="assets/img/logo.png" alt="">
            </div>
        </header>