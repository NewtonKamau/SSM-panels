        <div id="success" class="step">
            <span class="icon mdi mdi-check-circle color-green"></span>
            <h2 class="title">Success!</h2>
            <p>Application has been installed successfully!</p>
            
            <div class="sub">Don't forget to remove install directory!</div>

            <div class="go">
                <a href="../" class="oval button">Login</a>
            </div>
        </div>