// Home Animation Variables 

        jQuery('.follow') .addClass("hidden") .viewportChecker({

        classToAdd: 'visible animated fadeInDown',

        offset: 100
    });

         jQuery('.modules') .addClass("hidden") .viewportChecker({

        classToAdd: 'visible animated fadeInLeft',

        offset: 100
    });

        jQuery('.cloud') .addClass("hidden") .viewportChecker({

        classToAdd: 'visible animated fadeIn',

        offset: 100
    });

        jQuery('.price') .addClass("hidden") .viewportChecker({

        classToAdd: 'visible animated fadeInUp',

        offset: 100
    });

        jQuery('.price-h') .addClass("hidden") .viewportChecker({

        classToAdd: 'visible animated fadeInUp',

        offset: 100
    });

        jQuery('.schedule') .addClass("hidden") .viewportChecker({

        classToAdd: 'visible animated fadeInUp',

        offset: 100
    });
        jQuery('.difference') .addClass("hidden") .viewportChecker({

        classToAdd: 'visible animated fadeIn',

        offset: 100

    });
        jQuery('.difference-2') .addClass("hidden") .viewportChecker({

        classToAdd: 'visible animated fadeIn',

        offset: 100

    });

        jQuery('.credit-card') .addClass("hidden") .viewportChecker({

        classToAdd: 'visible animated fadeInLeft',

        offset: 100

    });
        jQuery('.video-player') .addClass("hidden") .viewportChecker({

        classToAdd: 'visible animated fadeInLeft',

        offset: 100

    });
        jQuery('.padlock') .addClass("hidden") .viewportChecker({

        classToAdd: 'visible animated fadeInLeft',

        offset: 100

    });

          jQuery('.difference-3') .addClass("hidden") .viewportChecker({

        classToAdd: 'visible animated fadeInUp',

        offset: 100

    });