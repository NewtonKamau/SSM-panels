<?php if (!defined('APP_VERSION')) die("Yo, what's up?"); ?>
<?php 
    return [
        "idname" => "auto-like",
        "plugin_name" => "Auto Like",
        "plugin_uri" => "http://getnextpost.io",
        "author" => "Nextpost",
        "author_uri" => "http://getnextpost.io",
        "version" => "4.1",
        "desc" => "One of the best modules to interact with new Instagram users.",
        "icon_style" => "background-color: #FD646B; background: linear-gradient(-135deg, #FD646B 0%, #FFD102 100%); color: #fff; font-size: 18px;",
        "settings_page_uri" => APPURL . "/e/auto-like/settings"
    ];
    